export type RulesetId = "dnd_2014" | "dnd_2024" | "homebrew";

export type AbilityKey = "str" | "dex" | "con" | "int" | "wis" | "cha";

export type AbilityScores = Record<AbilityKey, number>;

export type ArmorClassMode = "manual" | "auto";

export interface CharacterSpellSlot {
  level: number;
  max: number;
  used: number;
}

export interface CharacterInventoryItem {
  itemId: string;
  quantity: number;
  notes?: string;
  attuned?: boolean;
  chargesUsed?: number;
}

export interface CharacterDeathSaves {
  successes: number;
  failures: number;
}

export interface CharacterHitDiePool {
  die: number;
  max: number;
  used: number;
}

export type ResourceRecovery = "short" | "long" | "manual";

export interface CharacterResource {
  id: string;
  name: string;
  max: number;
  used: number;
  recovery: ResourceRecovery;
  unlimited?: boolean;
  shortRecoveryAmount?: number;
}
export interface CharacterClassLevel { className:string; level:number; subclass?:string }
export interface CharacterSpellEffect{ id:string;spellId:string;name:string;remainingRounds:number|null;concentration:boolean;summary:string;conditions?:CharacterCondition[];conditionChoice?:CharacterCondition[];repeatSave?:boolean;repeatSaveTiming?:"end-of-turn"|"start-of-turn"|"enter-or-start";endOnDamage?:boolean;endOnAllyAction?:boolean;endOnAttack?:boolean;endOnDealDamage?:boolean;endOnCastSpell?:boolean;attackRollBonusDice?:string|null;savingThrowBonusDice?:string|null;attackRollPenaltyDice?:string|null;savingThrowPenaltyDice?:string|null;armorClassBonus?:number;armorClassPenalty?:number;speedMultiplier?:number|null;speedBecomesZero?:boolean;dexteritySaveAdvantage?:boolean;extraLimitedAction?:boolean;difficultTerrain?:boolean;lethargyOnEnd?:boolean;immunityToMagicMissile?:boolean;teleportDistance?:number|null;flySpeed?:number|null;canHover?:boolean;duplicateCount?:number;duplicateInterceptionRule?:string|null;persistentKind?:"companion"|"steed"|"summon"|"persistent-area"|"persistent-weapon";persistentMoveDistance?:number|null;persistentMoveAction?:"action"|"bonus-action"|"magic-action"|"with-caster-movement"|null;persistentTriggers?:string[];persistentOncePerTurn?:boolean;persistentDamageFormula?:string|null;persistentSaveAbility?:"str"|"dex"|"con"|"int"|"wis"|"cha"|null;persistentSaveDamageRule?:"half"|"none"|null;persistentAttackUsesSpellAttack?:boolean;persistentArea?:string|null;persistentGuidance?:string[];summonInitiativeRule?:string|null;summonCommandEconomy?:string|null;summonCanAttack?:boolean|null;summonTouchSpellDelivery?:boolean;summonTelepathyRange?:number|null;summonFormChoices?:string[];summonCreatureTypeChoices?:string[];summonArmorClassFormula?:string|null;summonHitPointFormula?:string|null;summonFlySpeed?:number|null;summonSpecialScaling?:string|null;replacesExistingSummon?:boolean }

export type CharacterCondition =
  | "Blessed"
  | "Blinded"
  | "Charmed"
  | "Deafened"
  | "Frightened"
  | "Grappled"
  | "Incapacitated"
  | "Paralyzed"
  | "Petrified"
  | "Poisoned"
  | "Prone"
  | "Invisible"
  | "Stunned"
  | "Restrained"
  | "Unconscious"
  | "Concentration"
  | "Rage"
  | "Haki"
  | "Cursed";

export type CharacterConditionDurations = Partial<Record<CharacterCondition, number>>;

export interface Character {
  id: string;
  name: string;
  playerName: string;
  ruleset: RulesetId;

  race: string;
  subrace?: string;
  className: string;
  classLevels?: CharacterClassLevel[];
  subclass: string;
  background: string;
  originAbilityPrimary?: AbilityKey;
  originAbilitySecondary?: AbilityKey;
  originAbilityTertiary?: AbilityKey;
  originAbilityMode?: "2-1" | "1-1-1";
  flexibleRaceAbilityPrimary?: AbilityKey;
  flexibleRaceAbilitySecondary?: AbilityKey;
  abilityScoreIncreases?: Partial<Record<AbilityKey, number>>;
  featIds: string[];
  featChoices?: Record<string, string[]>;
  fightingStyleIds?: string[];
  masteredWeaponIds?: string[];
  metamagicIds?: string[];
  invocationIds?: string[];
  wildShapeFormIds?: string[];
  maneuverIds?: string[];
  companionId?: string;
  companionCurrentHp?: number;
  arcanumSpellIds?: string[];
  usedArcanumSpellIds?: string[];
  activeSpellEffects?: CharacterSpellEffect[];
  skillProficiencies: string[];
  expertiseSkills: string[];
  toolProficiencies: string[];
  languages: string[];
  level: number;

  abilities: AbilityScores;

  maxHp: number;
  currentHp: number;
  tempHp: number;
  armorClass: number;
  armorClassMode: ArmorClassMode;

  knownSpellIds: string[];
  preparedSpellIds: string[];
  spellSources?: Record<string, string>;
  classKnownSpellIds?: Record<string, string[]>;
  classPreparedSpellIds?: Record<string, string[]>;
  spellSlots: CharacterSpellSlot[];
  pactMagicSlots?: CharacterSpellSlot[];

  inventory: CharacterInventoryItem[];
  equippedArmorId: string | null;
  equippedShieldId: string | null;
  equippedWeaponIds: string[];
  gold: number;

  deathSaves: CharacterDeathSaves;
  hitDice: CharacterHitDiePool[];
  resources: CharacterResource[];
  exhaustion: number;
  conditionDurations: CharacterConditionDurations;

  conditions: CharacterCondition[];
  notes: string;

  createdAt: string;
  updatedAt: string;
}

export interface CharacterDraft {
  name: string;
  playerName: string;
  ruleset: RulesetId;

  race: string;
  subrace?: string;
  className: string;
  classLevels?: CharacterClassLevel[];
  subclass: string;
  background: string;
  originAbilityPrimary?: AbilityKey;
  originAbilitySecondary?: AbilityKey;
  originAbilityTertiary?: AbilityKey;
  originAbilityMode?: "2-1" | "1-1-1";
  flexibleRaceAbilityPrimary?: AbilityKey;
  flexibleRaceAbilitySecondary?: AbilityKey;
  abilityScoreIncreases?: Partial<Record<AbilityKey, number>>;
  featIds: string[];
  featChoices?: Record<string, string[]>;
  fightingStyleIds?: string[];
  masteredWeaponIds?: string[];
  metamagicIds?: string[];
  invocationIds?: string[];
  wildShapeFormIds?: string[];
  maneuverIds?: string[];
  companionId?: string;
  companionCurrentHp?: number;
  arcanumSpellIds?: string[];
  usedArcanumSpellIds?: string[];
  activeSpellEffects?: CharacterSpellEffect[];
  skillProficiencies: string[];
  expertiseSkills: string[];
  toolProficiencies: string[];
  languages: string[];
  level: number;

  abilities: AbilityScores;

  maxHp: number;
  armorClass: number;
  armorClassMode: ArmorClassMode;

  knownSpellIds: string[];
  preparedSpellIds: string[];
  spellSources?: Record<string, string>;
  classKnownSpellIds?: Record<string, string[]>;
  classPreparedSpellIds?: Record<string, string[]>;
  spellSlots: CharacterSpellSlot[];
  pactMagicSlots?: CharacterSpellSlot[];

  inventory: CharacterInventoryItem[];
  equippedArmorId: string | null;
  equippedShieldId: string | null;
  equippedWeaponIds: string[];
  gold: number;

  deathSaves: CharacterDeathSaves;
  hitDice: CharacterHitDiePool[];
  resources?: CharacterResource[];
  exhaustion: number;
  conditionDurations: CharacterConditionDurations;

  notes: string;
}

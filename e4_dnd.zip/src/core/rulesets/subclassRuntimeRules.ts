import type { CharacterResource } from "../character/character.types";
import type { DndSubclassData, SubclassFeatureData } from "./ruleset.types";
import { getUnlockedSubclassFeatures } from "./subclassRules";

export type SubclassActionType="action"|"bonus-action"|"reaction";
export type SubclassRuntimeAction={id:string;name:string;type:SubclassActionType;resourceId?:string;summary:string};
export type SubclassRuntime={unlockedFeatures:SubclassFeatureData[];actions:SubclassRuntimeAction[];criticalThreshold:number;attacksPerActionMinimum:number;armorClassFloor:number;damageResistances:string[];initiativeBonus:number;notes:string[]};

const feature=(features:SubclassFeatureData[],pattern:RegExp)=>features.find(item=>pattern.test(item.name));
const action=(id:string,name:string,type:SubclassActionType,summary:string,resourceId?:string):SubclassRuntimeAction=>({id,name,type,summary,...(resourceId?{resourceId}:{})});

export function getSubclassRuntime(subclass:DndSubclassData|null|undefined,level:number,dexModifier=0):SubclassRuntime{
 const unlocked=getUnlockedSubclassFeatures(subclass,level);const names=unlocked.map(item=>item.name).join(" | ");const subclassName=subclass?.name.toLowerCase()??"";const actions:SubclassRuntimeAction[]=[];
 if(/radiance of the dawn/i.test(names))actions.push(action("radiance-of-dawn","Radiance of the Dawn","action","Alan içindeki düşmanlara radiant Channel Divinity hasarı.","channel-divinity"));
 if(/preserve life/i.test(names))actions.push(action("preserve-life","Preserve Life","action","Channel Divinity havuzuyla hedefi en fazla yarı canına kadar iyileştir.","channel-divinity"));
 if(/invoke duplicity/i.test(names))actions.push(action("invoke-duplicity","Invoke Duplicity","action","Illusory duplicate oluştur.","channel-divinity"));
 if(subclass?.className.toLowerCase()==="cleric"&&/knowledge of the ages|charm animals and plants|artisan's blessing/i.test(names)){const selected=feature(unlocked,/knowledge of the ages|charm animals and plants|artisan's blessing/i)!;actions.push(action(`domain-${selected.name.toLowerCase().replace(/[^a-z0-9]+/g,"-")}`,selected.name,"action",selected.summary,"channel-divinity"))}
 if(subclass?.className.toLowerCase()==="paladin"&&/channel divinity/i.test(names))actions.push(action("oath-channel-divinity","Oath Channel Divinity","action","Seçili oath Channel Divinity etkisini uygula.","channel-divinity"));
 if(/improved warding flare|projected ward|branches of the tree|opportunist|entropic ward/i.test(names))actions.push(action("subclass-reaction",feature(unlocked,/improved warding flare|projected ward|branches of the tree|opportunist|entropic ward/i)!.name,"reaction","Subclass reaction özelliğini kullan."));
 if(/shadow step|moonlight step|transposition/i.test(names))actions.push(action("subclass-teleport",feature(unlocked,/shadow step|moonlight step|transposition/i)!.name,"bonus-action","Subclass hareket/teleport özelliğini kullan."));
 if(/combat wild shape|circle forms/i.test(names))actions.push(action("combat-wild-shape","Combat Wild Shape","bonus-action","Wild Shape kaynağıyla savaş formuna geç.","wild-shape"));
 if(/combat superiority/i.test(names))actions.push(action("combat-superiority","Combat Superiority","action","Seçili maneuver ile Superiority Die harca.","superiority-dice"));
 if(/shadow arts/i.test(names))actions.push(action("shadow-arts","Shadow Arts","action","Ki/Focus ile gölge tekniği kullan.","focus-points"));
 if(/cloak of shadows/i.test(names))actions.push(action("cloak-of-shadows","Cloak of Shadows","action","Uygun karanlıkta görünmezlik kazan."));
 if(/assassinate/i.test(names))actions.push(action("assassinate","Assassinate Opening","action","Henüz tur almamış hedefe açılış üstünlüğünü uygula."));
 if(subclass?.className.toLowerCase()==="ranger"&&/ranger's companion|primal companion/i.test(names))actions.push(action("command-companion","Command Companion","bonus-action","Companion hareket ve saldırısını yönet."));
 if(/combat inspiration/i.test(names))actions.push(action("combat-inspiration","Combat Inspiration","reaction","Bardic Inspiration zarını savunma veya hasar desteği için kullan.","bardic-inspiration"));
 if(/battle magic/i.test(names))actions.push(action("battle-magic","Battle Magic","bonus-action","Spell kullanımından sonra bonus action weapon attack yap."));
 if(/clairvoyant combatant/i.test(names))actions.push(action("clairvoyant-combatant","Clairvoyant Combatant","bonus-action","Zihinsel bağ kurulan hedefe karşı savaş üstünlüğünü etkinleştir."));
 if(/tides of chaos/i.test(names))actions.push(action("tides-of-chaos","Tides of Chaos","action","Bir D20 Test için advantage kazan."));
 if(/elder champion/i.test(names))actions.push(action("elder-champion","Elder Champion","bonus-action","Oath capstone dönüşümünü başlat."));
 if(/destructive wrath|guided strike|touch of death|arcane abjuration|path to the grave|twilight sanctuary|emboldening bond|order's demand/i.test(names)){const selected=feature(unlocked,/destructive wrath|guided strike|touch of death|arcane abjuration|path to the grave|twilight sanctuary|emboldening bond|order's demand/i)!;actions.push(action(`domain-${selected.name.toLowerCase().replace(/[^a-z0-9]+/g,"-")}`,selected.name,"action",selected.summary,"channel-divinity"))}
 if(/war priest/i.test(names))actions.push(action("war-priest","War Priest","bonus-action","Weapon attack sonrasında bonus action saldırısı."));
 if(/arcane ward/i.test(names))actions.push(action("arcane-ward","Arcane Ward","action","Abjuration ward HP havuzunu etkinleştir.","arcane-ward"));
 if(/bend luck/i.test(names))actions.push(action("bend-luck","Bend Luck","reaction","Yakındaki D20 sonucuna sorcery die uygula.","sorcery-points"));
 if(/wild magic surge/i.test(names))actions.push(action("wild-magic-surge","Wild Magic Surge","action","Wild Magic tablosu sonucunu tetikle."));
 if(subclass?.className.toLowerCase()==="barbarian"){
  const edition=subclass.ruleset;
  if(/frenzy/i.test(names)&&edition==="dnd_2014")actions.push(action("berserker-frenzy","Frenzy Attack","bonus-action","Rage sırasında sonraki turlarda bonus action melee weapon attack; Rage bitince exhaustion uygula."));
  if(/retaliation/i.test(names))actions.push(action("berserker-retaliation","Retaliation","reaction","5 feet içindeki saldırgana melee attack yap."));
  if(/intimidating presence/i.test(names))actions.push(action("berserker-intimidating-presence","Intimidating Presence",edition==="dnd_2024"?"bonus-action":"action",edition==="dnd_2024"?"30-foot emanation içinde Strength tabanlı save DC ile frightened uygula.":"Bir hedefe Wisdom save ile frightened uygula ve action ile sürdür."));
 }
 const champion=/champion/i.test(subclassName);const criticalThreshold=champion?(level>=15?18:level>=3?19:20):20;
 const valor=/college of valor/i.test(subclassName);const attacksPerActionMinimum=valor&&level>=6?2:1;
 const draconic=/draconic/i.test(subclassName);const armorClassFloor=draconic?13+dexModifier:0;
 const resistances:string[]=[];if(/spell resistance|aura of warding/i.test(names))resistances.push("spell");if(/avatar of battle/i.test(names))resistances.push("physical");if(/thought shield/i.test(names))resistances.push("psychic");
 const initiativeBonus=/assassin/i.test(subclassName)&&level>=3?2:0;
 const notes=unlocked.filter(item=>!actions.some(candidate=>candidate.name===item.name)).map(item=>`${item.name}: ${item.summary}`);
 return{unlockedFeatures:unlocked,actions,criticalThreshold,attacksPerActionMinimum,armorClassFloor,damageResistances:resistances,initiativeBonus,notes};
}

export function canUseSubclassAction(action:SubclassRuntimeAction,resources:CharacterResource[]){if(!action.resourceId)return true;const resource=resources.find(item=>item.id===action.resourceId);return Boolean(resource&&resource.used<resource.max)}
export function spendSubclassActionResource(action:SubclassRuntimeAction,resources:CharacterResource[]){if(!action.resourceId)return resources;return resources.map(item=>item.id===action.resourceId?{...item,used:Math.min(item.max,item.used+1)}:item)}

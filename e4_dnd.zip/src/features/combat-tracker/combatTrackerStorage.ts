import type { CampaignEncounter } from "../campaigns/campaignTypes";
export type CombatantKind = "Karakter" | "NPC" | "Canavar" | "Özel";
export type CombatCondition = "Blessed" | "Poisoned" | "Prone" | "Invisible" | "Stunned" | "Restrained" | "Concentration" | "Rage" | "Haki" | "Cursed";

export type CombatEffect = {
  id: string;
  condition: CombatCondition;
  remainingRounds: number | null;
  source: string;
};


export type BattlefieldZoneKind = "Aura" | "Hazard" | "Difficult Terrain" | "Spell Area" | "Cover" | "Other";
export type BattlefieldZoneShape = "Circle" | "Cone" | "Cube" | "Line" | "Sphere" | "Custom";

export type BattlefieldZone = {
  id: string;
  name: string;
  kind: BattlefieldZoneKind;
  shape: BattlefieldZoneShape;
  sizeFeet: number;
  remainingRounds: number | null;
  source: string;
  damage: string;
  saveDc: number | null;
  condition: CombatCondition | "";
  affectedCombatantIds: string[];
  notes: string;
};

export type CombatLogKind = "Sistem" | "Sıra" | "Hasar" | "İyileştirme" | "Etki" | "Alan" | "Not";

export type CombatLogEntry = {
  id: string;
  kind: CombatLogKind;
  round: number;
  combatantId: string;
  combatantName: string;
  amount: number | null;
  message: string;
  createdAt: string;
};

export type Combatant = {
  id: string;
  sourceId: string;
  name: string;
  kind: CombatantKind;
  initiative: number;
  armorClass: number;
  maxHp: number;
  currentHp: number;
  tempHp: number;
  conditions: CombatCondition[];
  effects: CombatEffect[];
  notes: string;
  isDefeated: boolean;
};


export type CombatTemplateCombatant = Pick<Combatant, "name" | "kind" | "initiative" | "armorClass" | "maxHp" | "conditions" | "notes">;

export type CombatTemplate = {
  id: string;
  name: string;
  campaignId: string;
  combatants: CombatTemplateCombatant[];
  createdAt: string;
  updatedAt: string;
};

export type CombatEncounter = {
  id: string;
  campaignId: string;
  name: string;
  round: number;
  activeCombatantId: string;
  combatants: Combatant[];
  log: CombatLogEntry[];
  zones: BattlefieldZone[];
  createdAt: string;
  updatedAt: string;
};

const STORAGE_KEY = "e4_dnd_combat_tracker_v1";
const TEMPLATE_STORAGE_KEY = "e4_dnd_combat_templates_v1";
const LOG_KINDS: readonly CombatLogKind[] = ["Sistem", "Sıra", "Hasar", "İyileştirme", "Etki", "Alan", "Not"];
export const BATTLEFIELD_ZONE_KINDS: readonly BattlefieldZoneKind[] = ["Aura", "Hazard", "Difficult Terrain", "Spell Area", "Cover", "Other"];
export const BATTLEFIELD_ZONE_SHAPES: readonly BattlefieldZoneShape[] = ["Circle", "Cone", "Cube", "Line", "Sphere", "Custom"];
const KINDS: readonly CombatantKind[] = ["Karakter", "NPC", "Canavar", "Özel"];
export const COMBAT_CONDITIONS: readonly CombatCondition[] = ["Blessed", "Poisoned", "Prone", "Invisible", "Stunned", "Restrained", "Concentration", "Rage", "Haki", "Cursed"];

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function finiteNumber(value: unknown, fallback = 0) {
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}


function sanitizeLogEntry(value: unknown): CombatLogEntry | null {
  if (!isRecord(value) || typeof value.id !== "string" || !LOG_KINDS.includes(value.kind as CombatLogKind)) return null;
  return {
    id: value.id,
    kind: value.kind as CombatLogKind,
    round: Math.max(1, Math.floor(finiteNumber(value.round, 1))),
    combatantId: typeof value.combatantId === "string" ? value.combatantId : "",
    combatantName: typeof value.combatantName === "string" ? value.combatantName : "",
    amount: value.amount === null ? null : Math.max(0, Math.floor(finiteNumber(value.amount))),
    message: typeof value.message === "string" ? value.message : "",
    createdAt: typeof value.createdAt === "string" ? value.createdAt : new Date().toISOString(),
  };
}

export function createCombatLogEntry(
  kind: CombatLogKind,
  round: number,
  message: string,
  combatant?: Pick<Combatant, "id" | "name"> | null,
  amount: number | null = null,
): CombatLogEntry {
  return {
    id: crypto.randomUUID(),
    kind,
    round: Math.max(1, Math.floor(round)),
    combatantId: combatant?.id ?? "",
    combatantName: combatant?.name ?? "",
    amount: amount === null ? null : Math.max(0, Math.floor(amount)),
    message: message.trim(),
    createdAt: new Date().toISOString(),
  };
}

export function addCombatLog(encounter: CombatEncounter, entry: CombatLogEntry): CombatEncounter {
  return { ...encounter, log: [entry, ...encounter.log].slice(0, 250) };
}

export function getCombatSummary(encounter: CombatEncounter) {
  const damage = encounter.log.filter((entry) => entry.kind === "Hasar").reduce((total, entry) => total + (entry.amount ?? 0), 0);
  const healing = encounter.log.filter((entry) => entry.kind === "İyileştirme").reduce((total, entry) => total + (entry.amount ?? 0), 0);
  const defeated = encounter.combatants.filter((combatant) => combatant.isDefeated).length;
  return {
    rounds: encounter.round,
    damage,
    healing,
    defeated,
    events: encounter.log.length,
  };
}

function sanitizeBattlefieldZone(value: unknown): BattlefieldZone | null {
  if (!isRecord(value) || typeof value.id !== "string" || typeof value.name !== "string") return null;
  const remainingRounds = value.remainingRounds === null ? null : Math.max(1, Math.floor(finiteNumber(value.remainingRounds, 1)));
  return {
    id: value.id,
    name: value.name.trim() || "Adsız alan",
    kind: BATTLEFIELD_ZONE_KINDS.includes(value.kind as BattlefieldZoneKind) ? value.kind as BattlefieldZoneKind : "Other",
    shape: BATTLEFIELD_ZONE_SHAPES.includes(value.shape as BattlefieldZoneShape) ? value.shape as BattlefieldZoneShape : "Custom",
    sizeFeet: Math.max(0, Math.floor(finiteNumber(value.sizeFeet))),
    remainingRounds,
    source: typeof value.source === "string" ? value.source : "",
    damage: typeof value.damage === "string" ? value.damage : "",
    saveDc: value.saveDc === null ? null : Math.max(0, Math.floor(finiteNumber(value.saveDc))),
    condition: COMBAT_CONDITIONS.includes(value.condition as CombatCondition) ? value.condition as CombatCondition : "",
    affectedCombatantIds: Array.isArray(value.affectedCombatantIds) ? value.affectedCombatantIds.filter((item): item is string => typeof item === "string") : [],
    notes: typeof value.notes === "string" ? value.notes : "",
  };
}

export function createBattlefieldZone(name = "Yeni alan", kind: BattlefieldZoneKind = "Spell Area"): BattlefieldZone {
  return { id: crypto.randomUUID(), name: name.trim() || "Yeni alan", kind, shape: "Circle", sizeFeet: 10, remainingRounds: 10, source: "", damage: "", saveDc: null, condition: "", affectedCombatantIds: [], notes: "" };
}

export function tickBattlefieldZones(zones: readonly BattlefieldZone[]) {
  return zones
    .map((zone) => zone.remainingRounds === null ? zone : { ...zone, remainingRounds: zone.remainingRounds - 1 })
    .filter((zone) => zone.remainingRounds === null || zone.remainingRounds > 0);
}

function sanitizeEffect(value: unknown): CombatEffect | null {
  if (!isRecord(value) || typeof value.id !== "string" || !COMBAT_CONDITIONS.includes(value.condition as CombatCondition)) return null;
  const duration = value.remainingRounds === null ? null : Math.max(1, Math.floor(finiteNumber(value.remainingRounds, 1)));
  return {
    id: value.id,
    condition: value.condition as CombatCondition,
    remainingRounds: duration,
    source: typeof value.source === "string" ? value.source : "",
  };
}

export function createCombatEffect(condition: CombatCondition, remainingRounds: number | null = null, source = ""): CombatEffect {
  return {
    id: crypto.randomUUID(),
    condition,
    remainingRounds: remainingRounds === null ? null : Math.max(1, Math.floor(remainingRounds)),
    source: source.trim(),
  };
}

export function getActiveConditions(combatant: Pick<Combatant, "conditions" | "effects">) {
  return Array.from(new Set([...combatant.conditions, ...combatant.effects.map((effect) => effect.condition)]));
}

export function sanitizeCombatant(value: unknown): Combatant | null {
  if (!isRecord(value) || typeof value.id !== "string" || typeof value.name !== "string") return null;
  const maxHp = Math.max(1, Math.floor(finiteNumber(value.maxHp, 1)));
  const conditions = Array.isArray(value.conditions) ? value.conditions.filter((item): item is CombatCondition => COMBAT_CONDITIONS.includes(item as CombatCondition)) : [];
  const effects = Array.isArray(value.effects) ? value.effects.map(sanitizeEffect).filter((item): item is CombatEffect => Boolean(item)) : [];
  return {
    id: value.id,
    sourceId: typeof value.sourceId === "string" ? value.sourceId : "",
    name: value.name.trim() || "Adsız savaşçı",
    kind: KINDS.includes(value.kind as CombatantKind) ? value.kind as CombatantKind : "Özel",
    initiative: Math.floor(finiteNumber(value.initiative)),
    armorClass: Math.max(0, Math.floor(finiteNumber(value.armorClass, 10))),
    maxHp,
    currentHp: Math.min(maxHp, Math.max(0, Math.floor(finiteNumber(value.currentHp, maxHp)))),
    tempHp: Math.max(0, Math.floor(finiteNumber(value.tempHp))),
    conditions,
    effects,
    notes: typeof value.notes === "string" ? value.notes : "",
    isDefeated: Boolean(value.isDefeated),
  };
}

export function sanitizeCombatEncounter(value: unknown): CombatEncounter | null {
  if (!isRecord(value) || typeof value.id !== "string" || typeof value.name !== "string") return null;
  const now = new Date().toISOString();
  const combatants = Array.isArray(value.combatants) ? value.combatants.map(sanitizeCombatant).filter((item): item is Combatant => Boolean(item)) : [];
  const activeCombatantId = typeof value.activeCombatantId === "string" && combatants.some((item) => item.id === value.activeCombatantId) ? value.activeCombatantId : combatants[0]?.id ?? "";
  return {
    id: value.id,
    campaignId: typeof value.campaignId === "string" ? value.campaignId : "",
    name: value.name.trim() || "Adsız karşılaşma",
    round: Math.max(1, Math.floor(finiteNumber(value.round, 1))),
    activeCombatantId,
    combatants: sortCombatants(combatants),
    log: Array.isArray(value.log) ? value.log.map(sanitizeLogEntry).filter((item): item is CombatLogEntry => Boolean(item)).slice(0, 250) : [],
    zones: Array.isArray(value.zones) ? value.zones.map(sanitizeBattlefieldZone).filter((item): item is BattlefieldZone => Boolean(item)).map((zone) => ({ ...zone, affectedCombatantIds: zone.affectedCombatantIds.filter((id) => combatants.some((combatant) => combatant.id === id)) })) : [],
    createdAt: typeof value.createdAt === "string" ? value.createdAt : now,
    updatedAt: typeof value.updatedAt === "string" ? value.updatedAt : now,
  };
}

export function createCombatEncounter(name = "Yeni savaş", campaignId = ""): CombatEncounter {
  const now = new Date().toISOString();
  return { id: crypto.randomUUID(), campaignId, name: name.trim() || "Yeni savaş", round: 1, activeCombatantId: "", combatants: [], log: [], zones: [], createdAt: now, updatedAt: now };
}

export function createCombatant(name = "Yeni savaşçı", kind: CombatantKind = "Özel"): Combatant {
  return { id: crypto.randomUUID(), sourceId: "", name: name.trim() || "Yeni savaşçı", kind, initiative: 0, armorClass: 10, maxHp: 1, currentHp: 1, tempHp: 0, conditions: [], effects: [], notes: "", isDefeated: false };
}

export function sortCombatants(combatants: readonly Combatant[]) {
  return [...combatants].sort((a, b) => b.initiative - a.initiative || a.name.localeCompare(b.name, "tr"));
}

export function tickCombatEffects(combatants: readonly Combatant[]) {
  return combatants.map((combatant) => ({
    ...combatant,
    effects: combatant.effects
      .map((effect) => effect.remainingRounds === null ? effect : { ...effect, remainingRounds: effect.remainingRounds - 1 })
      .filter((effect) => effect.remainingRounds === null || effect.remainingRounds > 0),
  }));
}

export function advanceTurn(encounter: CombatEncounter): CombatEncounter {
  if (!encounter.combatants.length) return encounter;
  const ordered = sortCombatants(encounter.combatants);
  const currentIndex = ordered.findIndex((item) => item.id === encounter.activeCombatantId);
  const nextIndex = currentIndex < 0 ? 0 : (currentIndex + 1) % ordered.length;
  const roundAdvanced = currentIndex >= 0 && nextIndex === 0;
  const combatants = roundAdvanced ? tickCombatEffects(ordered) : ordered;
  const zones = roundAdvanced ? tickBattlefieldZones(encounter.zones) : encounter.zones;
  return { ...encounter, combatants, zones, activeCombatantId: combatants[nextIndex].id, round: roundAdvanced ? encounter.round + 1 : encounter.round, updatedAt: new Date().toISOString() };
}

export function applyDamage(combatant: Combatant, amount: number): Combatant {
  let remaining = Math.max(0, Math.floor(amount));
  const tempAbsorbed = Math.min(combatant.tempHp, remaining);
  remaining -= tempAbsorbed;
  const currentHp = Math.max(0, combatant.currentHp - remaining);
  return { ...combatant, tempHp: combatant.tempHp - tempAbsorbed, currentHp, isDefeated: currentHp === 0 };
}

export function applyHealing(combatant: Combatant, amount: number): Combatant {
  const currentHp = Math.min(combatant.maxHp, combatant.currentHp + Math.max(0, Math.floor(amount)));
  return { ...combatant, currentHp, isDefeated: currentHp === 0 ? combatant.isDefeated : false };
}

export function loadCombatEncounters(): CombatEncounter[] {
  try {
    const parsed: unknown = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "[]");
    return Array.isArray(parsed) ? parsed.map(sanitizeCombatEncounter).filter((item): item is CombatEncounter => Boolean(item)) : [];
  } catch { return []; }
}

export function saveCombatEncounters(encounters: CombatEncounter[]) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(encounters)); } catch { /* localStorage kapalıysa oturum belleği devam eder. */ }
}


function sanitizeCombatTemplate(value: unknown): CombatTemplate | null {
  if (!isRecord(value) || typeof value.id !== "string" || typeof value.name !== "string") return null;
  const now = new Date().toISOString();
  const combatants = Array.isArray(value.combatants)
    ? value.combatants.map((item) => sanitizeCombatant({ ...(isRecord(item) ? item : {}), id: crypto.randomUUID(), sourceId: "", currentHp: isRecord(item) ? item.maxHp : 1, tempHp: 0, effects: [], isDefeated: false })).filter((item): item is Combatant => Boolean(item)).map(({ name, kind, initiative, armorClass, maxHp, conditions, notes }) => ({ name, kind, initiative, armorClass, maxHp, conditions, notes }))
    : [];
  return {
    id: value.id,
    name: value.name.trim() || "Adsız şablon",
    campaignId: typeof value.campaignId === "string" ? value.campaignId : "",
    combatants,
    createdAt: typeof value.createdAt === "string" ? value.createdAt : now,
    updatedAt: typeof value.updatedAt === "string" ? value.updatedAt : now,
  };
}

export function createCombatTemplate(encounter: CombatEncounter, name = encounter.name): CombatTemplate {
  const now = new Date().toISOString();
  return {
    id: crypto.randomUUID(),
    name: name.trim() || "Yeni savaş şablonu",
    campaignId: encounter.campaignId,
    combatants: encounter.combatants.map(({ name: combatantName, kind, initiative, armorClass, maxHp, conditions, notes }) => ({ name: combatantName, kind, initiative, armorClass, maxHp, conditions: [...conditions], notes })),
    createdAt: now,
    updatedAt: now,
  };
}

export function createEncounterFromCampaignEncounter(source: CampaignEncounter, campaignId: string): CombatEncounter {
  const encounter = createCombatEncounter(source.name, campaignId);
  const combatants = sortCombatants(source.participants.map((participant) => ({
    ...createCombatant(participant.name, participant.sourceType === "character" ? "Karakter" : "Canavar"),
    sourceId: participant.sourceId,
    initiative: participant.initiative ?? participant.initiativeModifier,
    armorClass: participant.armorClass,
    maxHp: participant.maxHp,
    currentHp: Math.min(participant.maxHp, Math.max(0, participant.currentHp)),
    conditions: [],
    notes: participant.notes,
    isDefeated: participant.currentHp <= 0,
  })));
  return { ...encounter, round: Math.max(1, source.round), combatants, activeCombatantId: combatants[0]?.id ?? "" };
}

export function createEncounterFromTemplate(template: CombatTemplate): CombatEncounter {
  const encounter = createCombatEncounter(template.name, template.campaignId);
  const combatants = sortCombatants(template.combatants.map((item) => ({ ...createCombatant(item.name, item.kind), initiative: item.initiative, armorClass: item.armorClass, maxHp: item.maxHp, currentHp: item.maxHp, conditions: [...item.conditions], notes: item.notes })));
  return { ...encounter, combatants, activeCombatantId: combatants[0]?.id ?? "" };
}

export function loadCombatTemplates(): CombatTemplate[] {
  try {
    const parsed: unknown = JSON.parse(localStorage.getItem(TEMPLATE_STORAGE_KEY) ?? "[]");
    return Array.isArray(parsed) ? parsed.map(sanitizeCombatTemplate).filter((item): item is CombatTemplate => Boolean(item)) : [];
  } catch { return []; }
}

export function saveCombatTemplates(templates: CombatTemplate[]) {
  try { localStorage.setItem(TEMPLATE_STORAGE_KEY, JSON.stringify(templates)); } catch { /* localStorage kapalıysa oturum belleği devam eder. */ }
}

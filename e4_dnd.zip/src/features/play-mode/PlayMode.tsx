import { useMemo, useState } from "react";
import { NavLink, useSearchParams } from "react-router-dom";
import type { AbilityKey, Character, CharacterCondition } from "../../core/character/character.types";
import type { RulesetData } from "../../core/rulesets/ruleset.types";
import { rollDice } from "../../core/dice/diceRoller";
import {
  formatModifier,
  getAbilityModifier,
  getInitiative,
  getProficiencyBonus,
  getSpellAttackBonus,
  getSpellSaveDc,
} from "../../core/character/characterCalculator";
import { PageShell } from "../../shared/layout/PageShell";
import { getPlayReadiness } from "../../core/character/playReadiness";
import { getCharacterSpellcastingAbility } from "../../core/character/playerJourneyConsistency";
import { useI18n } from "../../shared/i18n/useI18n";
import { getMetamagicOptions } from "../../core/rulesets/metamagicRules";
import { getEldritchInvocations } from "../../core/rulesets/invocationRules";
import { getWildShapeForms } from "../../core/rulesets/wildShapeRules";
import { getBattleMasterManeuvers, getSuperiorityDie } from "../../core/rulesets/maneuverRules";
import { getCompanionStats, getRangerCompanions } from "../../core/rulesets/companionRules";
import { getClassFeatureActions } from "../../core/rulesets/classFeatureEngine";
import { getDivineSmiteDice, getPaladinAuraSummary, isPaladin } from "../../core/rulesets/paladinRules";
import { getCastableSlotLevels, getSpellRollFormula, rollFormula } from "../../core/rulesets/spellResolution";
import { addSpellEffect, advanceSpellEffects, createSpellEffect, removeEffectsBrokenByDamage } from "../../core/rulesets/spellEffectRules";
import { applyDamage, applyHealing, resolveDeathSave } from "../../core/character/survivalRules";
import { getCriticalDamageFormula, resolveAttack, type RollMode } from "../../core/rulesets/attackResolution";
import { combineRollModes, getConditionEffects } from "../../core/rulesets/conditionRules";
import { getSavingThrowBonus, getSkillBonus, SKILL_ABILITIES } from "../../core/rulesets/characterSheetRules";
import { chooseD20 } from "../../core/rulesets/attackResolution";
import { getEffectiveMaxHp, getEffectiveSpeed, getExhaustionEffects } from "../../core/rulesets/exhaustionRules";
import { getDefaultSaveDamageRule, resolveSaveDamage, resolveTargetSave, type SaveDamageRule } from "../../core/rulesets/spellTargetRules";
import { createTurnEconomy, getAttacksPerAction, spendAttack, spendMovement, spendTurnResource } from "../../core/rulesets/actionEconomyRules";
import { canUseSneakAttack, getRogueCombatFeatures, getSneakAttackDice } from "../../core/rulesets/rogueRules";
import { getBarbarianCombatFeatures, getBrutalCriticalExtraDice, getBrutalStrike, getRageDamageBonus, getRelentlessRageRecoveryHp, isRageDamageWeapon, reduceRageDamage } from "../../core/rulesets/barbarianRules";
import { getMartialArtsDie, getMonkCombatFeatures, getUnarmoredMovementBonus } from "../../core/rulesets/monkRules";
import { getBardCombatFeatures, getBardicInspirationDie, getInspirationRecovery } from "../../core/rulesets/bardRules";
import { getFighterCombatFeatures, getIndomitableBonus } from "../../core/rulesets/fighterRules";
import { getClericCombatFeatures, getDivineSparkDice } from "../../core/rulesets/clericRules";
import { getLifeDomainHealing, getPreserveLifeHealing } from "../../core/rulesets/clericDomainRules";
import { canCreateSorcerySlot, getPointsFromSlot, getSorcererCombatFeatures, getSorcerySlotCost } from "../../core/rulesets/sorcererRules";
import { canRecoverWizardSlot, getArcaneRecoveryBudget, getWizardCombatFeatures } from "../../core/rulesets/wizardRules";
import { getHuntersMarkDamage, getRangerCombatFeatures } from "../../core/rulesets/rangerRules";
import { getFeatRuntime } from "../../core/rulesets/featRuntimeRules";
import { consumeInventoryItem, createItemEffect, getItemDamageProfile, getItemHealingFormula, getItemRestoration, isConsumableItem } from "../../core/rulesets/itemUseRules";
import { getItemEffectRuntime, getItemTempHp, removeFragileItemEffects } from "../../core/rulesets/itemEffectRuntimeRules";
import { getMagicWeaponExtraDamage, type MagicWeaponTarget } from "../../core/rulesets/magicWeaponRules";
import { getMagicArmorRuntime } from "../../core/rulesets/magicArmorRules";
import { getMagicAccessoryRuntime } from "../../core/rulesets/magicAccessoryRules";
import { resolveWeaponMastery } from "../../core/rulesets/weaponMasteryRuntimeRules";
import { getInterceptionReduction, getOffhandDamageModifier, rollStyledWeaponDamage } from "../../core/rulesets/fightingStyleRuntimeRules";
import { getAncestryRuntime, getAncestrySaveMode, reduceAncestryDamage } from "../../core/rulesets/ancestryRuntimeRules";
import { applyReliableTalent, getCapstoneSummary, getClassAbilityRuntime } from "../../core/rulesets/classCompletionRules";
import { canUseSubclassAction, getSubclassRuntime, spendSubclassActionResource, type SubclassRuntimeAction } from "../../core/rulesets/subclassRuntimeRules";
import { getAdvancedFeatRuntime, getInspiringLeaderTempHp, type FeatAction } from "../../core/rulesets/advancedFeatRuntimeRules";
import { getSpellBehavior } from "../../core/rulesets/spellBehaviorRules";
import { getSpellMaterialReadiness } from "../../core/rulesets/spellMaterialRules";
import { getActiveDefenseMovementModifiers, removeEffectsBrokenByAttack, removeEffectsBrokenBySpellCast } from "../../core/rulesets/spellDefenseMovementRules";
import { getEncumbrance, getEquipmentLegality, getInventoryWeight, findAmmunitionId, consumeAmmunition } from "../../core/rulesets/equipmentRuntimeRules";
import { getMulticlassAttacksPerAction, normalizeClassLevels } from "../../core/rulesets/multiclassRules";
import { getSpellcastingStatsForSpell } from "../../core/rulesets/multiclassSpellcastingSeparation";
import { loadHomebrewPackages } from "../homebrew/homebrewStorage";
import { executeHomebrewRuntimeAction, getHomebrewCharacterRuntime, recoverHomebrewCharacterResources, synchronizeHomebrewResources } from "../../core/homebrew/homebrewRuntimeIntegration";
import { getHomebrewContentRuntime } from "../../core/homebrew/homebrewContentRuntimeIntegration";
import { getAttunedItemCount, recoverHighestSpentSpellSlot, recoverItemCharges, spendItemCharge, toggleItemAttunement } from "../../core/rulesets/magicItemRules";
import {
  calculateEffectiveArmorClass,
  getEquippedItems,
  getSpellLevelGroups,
  getWeaponAttackBonus,
  getWeaponAbilityModifier,
  getWeaponDamageSummary,
  isSpellReadyToCast,
  normalizeHitDice,
  normalizeSpellSlots,
  resetDeathSaves,
  resetHitDice,
  resetSpellSlots,
  sortSpellsByLevelAndName,
} from "../characters/characterShared";

const conditionOptions: CharacterCondition[] = [
  "Blessed",
  "Blinded",
  "Charmed",
  "Deafened",
  "Frightened",
  "Grappled",
  "Incapacitated",
  "Paralyzed",
  "Petrified",
  "Poisoned",
  "Prone",
  "Invisible",
  "Stunned",
  "Restrained",
  "Unconscious",
  "Concentration",
  "Rage",
  "Haki",
  "Cursed",
];

const abilityLabels: Record<AbilityKey, string> = {
  str: "STR",
  dex: "DEX",
  con: "CON",
  int: "INT",
  wis: "WIS",
  cha: "CHA",
};

type RollResult = {
  id: string;
  label: string;
  notation: string;
  total: number;
};

export function PlayMode({
  characters,
  rulesetData,
  onUpdateCharacter,
}: {
  characters: Character[];
  rulesetData: RulesetData | null;
  onUpdateCharacter: (character: Character) => void;
}) {
  const { t } = useI18n();
  const [searchParams, setSearchParams] = useSearchParams();
  const [selectedCharacterId, setSelectedCharacterId] = useState(
    () => searchParams.get("character") ?? characters[0]?.id ?? "",
  );
  const [rollHistory, setRollHistory] = useState<RollResult[]>([]);
  const [isFocusMode, setIsFocusMode] = useState(false);
  const [smiteHolyTarget,setSmiteHolyTarget]=useState(false);
  const [castSlotLevels,setCastSlotLevels]=useState<Record<string,number>>({});
  const [survivalAmount,setSurvivalAmount]=useState(1);
  const [pendingConcentrationDc,setPendingConcentrationDc]=useState<number|null>(null);
  const [targetAc,setTargetAc]=useState(10);
  const [attackMode,setAttackMode]=useState<RollMode>("normal");
  const [checkMode,setCheckMode]=useState<RollMode>("normal");
  const [spellTargetMode,setSpellTargetMode]=useState<RollMode>("normal");
  const [targetSaveBonus,setTargetSaveBonus]=useState(0);
  const [saveDamageRule,setSaveDamageRule]=useState<"auto"|SaveDamageRule>("auto");
  const [turnEconomy,setTurnEconomy]=useState(createTurnEconomy);
  const [arcaneRecoveryLevels,setArcaneRecoveryLevels]=useState<number[]>([]);
  const [luckyUsed,setLuckyUsed]=useState(0);
  const [sneakAttackUsed,setSneakAttackUsed]=useState(false);
  const [sneakAttackEnabled,setSneakAttackEnabled]=useState(true);
  const [sneakAllyAdjacent,setSneakAllyAdjacent]=useState(false);
  const [recklessAttack,setRecklessAttack]=useState(false);
  const [incomingPhysical,setIncomingPhysical]=useState(true);
  const [incomingPotionResisted,setIncomingPotionResisted]=useState(false);
  const [magicWeaponTarget,setMagicWeaponTarget]=useState<MagicWeaponTarget>("normal");
  const [incomingDamageType,setIncomingDamageType]=useState("physical");
  const [masteryVexReady,setMasteryVexReady]=useState(false);
  const [offhandAttack,setOffhandAttack]=useState(false);
  const [powerAttack,setPowerAttack]=useState(false);
  const [featActionUses,setFeatActionUses]=useState<Record<string,number>>({});
  const [spellTargetCount,setSpellTargetCount]=useState(1);
  const [homebrewPackages] = useState(() => loadHomebrewPackages());

  const character =
    characters.find((item) => item.id === selectedCharacterId) ?? characters[0];

  const preparedSpellIds = useMemo(
    () => new Set(character?.preparedSpellIds ?? []),
    [character?.preparedSpellIds],
  );

  if (!character) {
    return (
      <PageShell
        eyebrow="Table Mode"
        title="Play Mode"
        description="Önce bir karakter oluşturmalısın. Uygulama kahramanı havadan üretmiyor, henüz."
      >
        <div className="empty-panel">Play Mode için kayıtlı karakter bulunamadı.</div>
      </PageShell>
    );
  }

  const activeCharacter = character;
  const homebrewRuntime = getHomebrewCharacterRuntime(activeCharacter, homebrewPackages);
  const homebrewContentRuntime = getHomebrewContentRuntime(activeCharacter, homebrewPackages, rulesetData);
  const classAbilities=getClassAbilityRuntime(activeCharacter.abilities,activeCharacter.className,activeCharacter.level);
  const magicAccessoryRuntime=getMagicAccessoryRuntime(classAbilities,activeCharacter.inventory,rulesetData?.items);
  const effectiveCharacter={...activeCharacter,abilities:magicAccessoryRuntime.abilities};
  const spellSlots = normalizeSpellSlots(
    activeCharacter.spellSlots,
    activeCharacter.level,
    activeCharacter.className,
  );
  const pactMagicSlots=activeCharacter.pactMagicSlots??[];
  const selectedClass = rulesetData?.classes.find(
    (item) => item.name === activeCharacter.className,
  );
  const classLevels=normalizeClassLevels(activeCharacter.classLevels,activeCharacter.className,activeCharacter.level);
  const classProfiles=(rulesetData?.classes??[]).filter(item=>classLevels.some(level=>level.className===item.name));
  const selectedSubclass=rulesetData?.subclasses.find(item=>item.name===activeCharacter.subclass&&item.className===activeCharacter.className);
  const subclassRuntime=getSubclassRuntime(selectedSubclass,activeCharacter.level,getAbilityModifier(effectiveCharacter.abilities.dex));
  const spellcastingAbility:AbilityKey=getCharacterSpellcastingAbility(activeCharacter,rulesetData);
  const hitDice = normalizeHitDice(
    activeCharacter.hitDice,
    activeCharacter.level,
    activeCharacter.className,
    selectedClass?.hitDie,
  );
  const spells = sortSpellsByLevelAndName(
    rulesetData?.spells.filter(
      (spell) =>
        activeCharacter.knownSpellIds?.includes(spell.id) &&
        isSpellReadyToCast(spell, preparedSpellIds),
    ) ?? [],
  );
  const spellGroups = getSpellLevelGroups(spells);
  const equippedItems = getEquippedItems(effectiveCharacter, rulesetData?.items);
  const baseArmorClass = calculateEffectiveArmorClass(
    effectiveCharacter,
    rulesetData?.items,
  );
  const readiness = getPlayReadiness(activeCharacter, rulesetData);
  const metamagicOptions = getMetamagicOptions(activeCharacter.ruleset).filter((option) =>
    activeCharacter.metamagicIds?.includes(option.id),
  );
  const sorceryPoints = activeCharacter.resources.find((resource) => resource.id === "sorcery-points");
  const invocations = getEldritchInvocations(activeCharacter.ruleset).filter((option) => activeCharacter.invocationIds?.includes(option.id));
  const wildShapeForms = getWildShapeForms().filter((form) => activeCharacter.wildShapeFormIds?.includes(form.id));
  const wildShapeResource = activeCharacter.resources.find((resource) => resource.id === "wild-shape");
  const maneuvers=getBattleMasterManeuvers().filter(item=>activeCharacter.maneuverIds?.includes(item.id));
  const superiorityDice=activeCharacter.resources.find(resource=>resource.id==="superiority-dice");
  const companion=getRangerCompanions(activeCharacter.ruleset).find(item=>item.id===activeCharacter.companionId);
  const companionStats=companion?getCompanionStats(companion,activeCharacter.level,getAbilityModifier(effectiveCharacter.abilities.wis)):null;
  const companionCurrentHp=companionStats?Math.min(companionStats.maxHp,Math.max(0,activeCharacter.companionCurrentHp??companionStats.maxHp)):0;
  const handledResourceIds=new Set(["sorcery-points","wild-shape","superiority-dice","focus-points","bardic-inspiration","second-wind","action-surge","indomitable","channel-divinity","arcane-recovery","favored-enemy"]);
  const classActions=getClassFeatureActions(activeCharacter.className,activeCharacter.level,activeCharacter.ruleset).filter(action=>action.resourceId&&!handledResourceIds.has(action.resourceId)&&activeCharacter.resources.some(resource=>resource.id===action.resourceId));
  const arcanumSpells=(rulesetData?.spells??[]).filter(spell=>activeCharacter.arcanumSpellIds?.includes(spell.id));
  const paladinAuras=isPaladin(activeCharacter.className)?getPaladinAuraSummary(activeCharacter.level):null;
  const activeSpellEffects=activeCharacter.activeSpellEffects??[];
  const itemEffectRuntime=getItemEffectRuntime(activeSpellEffects);
  const spellDefenseMovementRuntime=getActiveDefenseMovementModifiers(activeSpellEffects);
  const magicArmorRuntime=getMagicArmorRuntime(activeCharacter,rulesetData?.items);
  const selectedFeats=rulesetData?.feats.filter(feat=>activeCharacter.featIds.includes(feat.id))??[];
  const advancedFeatRuntime=getAdvancedFeatRuntime(selectedFeats,activeCharacter.level);
  const mediumArmorMasterBonus=equippedItems.armor?.armorType==="medium"&&getAbilityModifier(effectiveCharacter.abilities.dex)>=3&&advancedFeatRuntime.mediumArmorDexCap>=3?1:0;
  const armorClass=Math.max(baseArmorClass+itemEffectRuntime.armorClassBonus+spellDefenseMovementRuntime.armorClassBonus+advancedFeatRuntime.armorClassBonus+mediumArmorMasterBonus,subclassRuntime.armorClassFloor);
  const conditionEffects=getConditionEffects(activeCharacter.conditions);
  const exhaustionEffects=getExhaustionEffects(activeCharacter.ruleset,activeCharacter.exhaustion);
  const selectedRace=rulesetData?.races.find(race=>race.name===activeCharacter.race);
  const ancestryRuntime=getAncestryRuntime(selectedRace,activeCharacter.subrace,activeCharacter.level);
  const combinedSaveRuntime=advancedFeatRuntime.mentalSaveAdvantage?{...ancestryRuntime,saveAdvantages:[...new Set([...ancestryRuntime.saveAdvantages,"int" as const,"wis" as const,"cha" as const])]}:ancestryRuntime;
  const selectedBackground=rulesetData?.backgrounds.find(background=>background.name===activeCharacter.background);
  const featNames=[...(rulesetData?.feats.filter(feat=>activeCharacter.featIds.includes(feat.id)).map(feat=>feat.name)??[]),...(selectedBackground?.originFeat?[selectedBackground.originFeat]:[])];
  const featRuntime=getFeatRuntime(featNames,activeCharacter.level,activeCharacter.ruleset);
  const usableItems=activeCharacter.inventory.flatMap(entry=>{const item=rulesetData?.items.find(candidate=>candidate.id===entry.itemId);return item&&isConsumableItem(item)?[{entry,item}]:[]});
  const magicItems=activeCharacter.inventory.flatMap(entry=>{const item=rulesetData?.items.find(candidate=>candidate.id===entry.itemId);return item?.magical?[{entry,item}]:[]});
  const inventoryWeight=getInventoryWeight(activeCharacter.inventory,rulesetData?.items??[]);
  const encumbrance=getEncumbrance(effectiveCharacter.abilities.str,inventoryWeight);
  const armorLegality=equippedItems.armor?getEquipmentLegality(equippedItems.armor,classProfiles,effectiveCharacter.abilities):null;
  const effectiveSpeed=Math.max(0,getEffectiveSpeed(((selectedRace?.speed??30)+ancestryRuntime.speedBonus+featRuntime.speedBonus+magicAccessoryRuntime.speedBonus)*itemEffectRuntime.speedMultiplier,exhaustionEffects)-(armorLegality?.speedPenalty??0)-encumbrance.speedPenalty);
  const effectiveMaxHp=getEffectiveMaxHp(activeCharacter.maxHp,exhaustionEffects);
  const attacksPerAction=Math.max(getAttacksPerAction(activeCharacter.className,activeCharacter.level),getMulticlassAttacksPerAction(classLevels),subclassRuntime.attacksPerActionMinimum);
  const isRogue=activeCharacter.className.trim().toLowerCase()==="rogue";
  const rogueFeatures=getRogueCombatFeatures(activeCharacter.level,activeCharacter.ruleset==="dnd_2024"?"dnd_2024":"dnd_2014");
  const isBarbarian=activeCharacter.className.trim().toLowerCase()==="barbarian";
  const barbarianFeatures=getBarbarianCombatFeatures(activeCharacter.level);
  const isRaging=activeCharacter.conditions.includes("Rage");
  const isMonk=activeCharacter.className.trim().toLowerCase()==="monk";
  const monkFeatures=getMonkCombatFeatures(activeCharacter.level,activeCharacter.ruleset==="dnd_2024"?"dnd_2024":"dnd_2014");
  const focusPoints=activeCharacter.resources.find(resource=>resource.id==="focus-points");
  const isBard=activeCharacter.className.trim().toLowerCase()==="bard";
  const bardFeatures=getBardCombatFeatures(activeCharacter.level,activeCharacter.ruleset);
  const bardicInspiration=activeCharacter.resources.find(resource=>resource.id==="bardic-inspiration");
  const isFighter=activeCharacter.className.trim().toLowerCase()==="fighter";
  const fighterFeatures=getFighterCombatFeatures(activeCharacter.level,activeCharacter.ruleset==="dnd_2024"?"dnd_2024":"dnd_2014");
  const actionSurge=activeCharacter.resources.find(resource=>resource.id==="action-surge");
  const indomitable=activeCharacter.resources.find(resource=>resource.id==="indomitable");
  const secondWind=activeCharacter.resources.find(resource=>resource.id==="second-wind");
  const isCleric=activeCharacter.className.trim().toLowerCase()==="cleric";
  const clericFeatures=getClericCombatFeatures(activeCharacter.level,activeCharacter.ruleset);
  const channelDivinity=activeCharacter.resources.find(resource=>resource.id==="channel-divinity");
  const isSorcerer=activeCharacter.className.trim().toLowerCase()==="sorcerer";
  const sorcererFeatures=getSorcererCombatFeatures(activeCharacter.level);
  const isWizard=activeCharacter.className.trim().toLowerCase()==="wizard";
  const wizardFeatures=getWizardCombatFeatures(activeCharacter.level);
  const arcaneRecovery=activeCharacter.resources.find(resource=>resource.id==="arcane-recovery");
  const isRanger=activeCharacter.className.trim().toLowerCase()==="ranger";
  const rangerFeatures=getRangerCombatFeatures(activeCharacter.level,activeCharacter.ruleset,getAbilityModifier(activeCharacter.abilities.wis));
  const favoredEnemy=activeCharacter.resources.find(resource=>resource.id==="favored-enemy");
  const capstoneSummary=getCapstoneSummary(activeCharacter.className,activeCharacter.level,activeCharacter.ruleset);

  function commit(patch: Partial<Character>) {
    onUpdateCharacter({
      ...activeCharacter,
      ...patch,
      updatedAt: new Date().toISOString(),
    });
  }

  function syncHomebrewResources(){commit({resources:synchronizeHomebrewResources(activeCharacter,homebrewPackages)})}
  function executeHomebrewAction(actionId:string){const next=executeHomebrewRuntimeAction(activeCharacter,homebrewPackages,actionId);onUpdateCharacter(next);const action=homebrewRuntime.actions.find(item=>item.id===actionId);if(action)setRollHistory(current=>[{id:crypto.randomUUID(),label:action.action.name,notation:action.action.economy,total:action.action.resourceCost??0},...current].slice(0,6))}

  function spendSorceryPoints(cost: number) {
    if (!sorceryPoints || sorceryPoints.max - sorceryPoints.used < cost) return;
    commit({
      resources: activeCharacter.resources.map((resource) =>
        resource.id === "sorcery-points"
          ? { ...resource, used: Math.min(resource.max, resource.used + cost) }
          : resource,
      ),
    });
  }

  function useWildShape() {
    if (!wildShapeResource || wildShapeResource.used >= wildShapeResource.max) return;
    commit({ resources: activeCharacter.resources.map(resource=>resource.id==="wild-shape"?{...resource,used:Math.min(resource.max,resource.used+1)}:resource) });
  }
  function useSuperiorityDie(){if(!superiorityDice||superiorityDice.used>=superiorityDice.max)return;commit({resources:activeCharacter.resources.map(resource=>resource.id==="superiority-dice"?{...resource,used:Math.min(resource.max,resource.used+1)}:resource)})}
  function updateCompanionHp(amount:number){if(!companionStats)return;commit({companionCurrentHp:Math.min(companionStats.maxHp,Math.max(0,companionCurrentHp+amount))})}
  function executeClassAction(resourceId:string,amount=1){const resource=activeCharacter.resources.find(item=>item.id===resourceId);if(!resource||(!resource.unlimited&&resource.max-resource.used<amount))return;let currentHp=activeCharacter.currentHp;let conditions=activeCharacter.conditions;if(resourceId==="second-wind"){const result=rollDice({count:1,sides:10,modifier:activeCharacter.level});currentHp=Math.min(activeCharacter.maxHp,currentHp+result.total);setRollHistory(current=>[{id:result.id,label:"Second Wind",notation:result.notation,total:result.total},...current].slice(0,6))}if(resourceId==="lay-on-hands")currentHp=Math.min(activeCharacter.maxHp,currentHp+amount);if(resourceId==="rage"&&!conditions.includes("Rage"))conditions=[...conditions,"Rage"];commit({currentHp,conditions,resources:activeCharacter.resources.map(item=>item.id===resourceId?item.unlimited?item:{...item,used:Math.min(item.max,item.used+amount)}:item)})}
  function castArcanum(spellId:string){if(activeCharacter.usedArcanumSpellIds?.includes(spellId))return;commit({usedArcanumSpellIds:[...(activeCharacter.usedArcanumSpellIds??[]),spellId]})}
  function divineSmite(slotLevel:number){const slot=spellSlots.find(item=>item.level===slotLevel);if(!slot||slot.used>=slot.max)return;const dice=getDivineSmiteDice(slotLevel,activeCharacter.ruleset,smiteHolyTarget);const result=rollDice({count:dice,sides:8,modifier:0});commit({spellSlots:spellSlots.map(item=>item.level===slotLevel?{...item,used:item.used+1}:item)});setRollHistory(current=>[{id:result.id,label:`Divine Smite · Level ${slotLevel}`,notation:result.notation,total:result.total},...current].slice(0,6))}
  function advanceEffectRound(){const next=advanceSpellEffects(activeSpellEffects);commit({activeSpellEffects:next,conditions:next.some(effect=>effect.concentration)?activeCharacter.conditions:activeCharacter.conditions.filter(condition=>condition!=="Concentration")})}
  function endSpellEffect(id:string){const next=activeSpellEffects.filter(effect=>effect.id!==id);commit({activeSpellEffects:next,conditions:next.some(effect=>effect.concentration)?activeCharacter.conditions:activeCharacter.conditions.filter(condition=>condition!=="Concentration")})}
  function concentrationSave(dc:number){const modifier=getAbilityModifier(effectiveCharacter.abilities.con)+magicAccessoryRuntime.savingThrowBonus;const result=rollDice({count:advancedFeatRuntime.concentrationAdvantage?2:1,sides:20,modifier:0});const natural=advancedFeatRuntime.concentrationAdvantage?Math.max(...result.rolls):result.rolls[0];const total=natural+modifier;const success=total>=dc;commit(success?{}:{activeSpellEffects:activeSpellEffects.filter(effect=>!effect.concentration),conditions:activeCharacter.conditions.filter(condition=>condition!=="Concentration")});setPendingConcentrationDc(null);setRollHistory(current=>[{id:result.id,label:`Concentration Save DC ${dc} · ${success?"Başarılı":"Başarısız"}`,notation:`${advancedFeatRuntime.concentrationAdvantage?"advantage":"normal"} · [${result.rolls.join(", ")}] ${formatModifier(modifier)}`,total},...current].slice(0,6))}

  function takeDamage(critical=false){const rageReduced=reduceRageDamage(survivalAmount,isRaging,incomingPhysical);const ancestryReduced=reduceAncestryDamage(rageReduced,incomingDamageType,ancestryRuntime);const subclassResisted=subclassRuntime.damageResistances.includes(incomingDamageType);const subclassReduced=subclassResisted?Math.ceil(ancestryReduced/2):ancestryReduced;const armorResisted=magicArmorRuntime.resistanceDamageTypes.includes(incomingDamageType);const potionResisted=itemEffectRuntime.damageResistance&&incomingPotionResisted;const finalDamage=armorResisted||potionResisted?Math.ceil(subclassReduced/2):subclassReduced;const effectiveCritical=critical&&!magicArmorRuntime.preventsCriticalDamage;const result=applyDamage({currentHp:activeCharacter.currentHp,maxHp:activeCharacter.maxHp,tempHp:activeCharacter.tempHp,deathSaves:activeCharacter.deathSaves},finalDamage,effectiveCritical);const damageBrokenEffects=removeEffectsBrokenByDamage(activeSpellEffects);commit({currentHp:result.currentHp,tempHp:result.tempHp,deathSaves:result.deathSaves,activeSpellEffects:damageBrokenEffects,conditions:damageBrokenEffects.some(effect=>effect.concentration)?activeCharacter.conditions:activeCharacter.conditions.filter(condition=>condition!=="Concentration")});if(damageBrokenEffects.some(effect=>effect.concentration))setPendingConcentrationDc(result.concentrationDc);setRollHistory(current=>[{id:crypto.randomUUID(),label:`${critical?"Kritik ":""}Hasar${critical&&!effectiveCritical?" · Adamantine":""}${rageReduced!==survivalAmount?" · Rage Resistance":""}${ancestryReduced!==rageReduced?" · Ancestry Resistance":""}${subclassResisted?" · Subclass Resistance":""}${armorResisted?" · Armor Resistance":potionResisted?" · Potion Resistance":""}${result.absorbedByTempHp?` · ${result.absorbedByTempHp} Temp HP emdi`:""}`,notation:`-${finalDamage} HP`,total:-finalDamage},...current].slice(0,6))}
  function healDamage(){const result=applyHealing({currentHp:activeCharacter.currentHp,maxHp:activeCharacter.maxHp,tempHp:activeCharacter.tempHp,deathSaves:activeCharacter.deathSaves},survivalAmount);commit({currentHp:result.currentHp,deathSaves:result.deathSaves})}
  function rollDeathSave(){const roll=rollDice({count:1,sides:20,modifier:0});const result=resolveDeathSave({currentHp:activeCharacter.currentHp,maxHp:activeCharacter.maxHp,tempHp:activeCharacter.tempHp,deathSaves:activeCharacter.deathSaves},roll.rolls[0]);commit({currentHp:result.currentHp,deathSaves:result.deathSaves});setRollHistory(current=>[{id:roll.id,label:`Death Save${roll.rolls[0]===20?" · Natural 20":roll.rolls[0]===1?" · Natural 1":""}`,notation:roll.notation,total:roll.total},...current].slice(0,6))}

  function updateHp(amount: number) {
    commit({
      currentHp: Math.max(
        0,
        Math.min(activeCharacter.maxHp, activeCharacter.currentHp + amount),
      ),
    });
  }

  function toggleCondition(condition: CharacterCondition) {
    const active = activeCharacter.conditions.includes(condition);
    const conditionDurations = { ...(activeCharacter.conditionDurations ?? {}) };

    if (active) {
      delete conditionDurations[condition];
    }

    commit({
      conditions: active
        ? activeCharacter.conditions.filter((item) => item !== condition)
        : [...activeCharacter.conditions, condition],
      conditionDurations,
    });
  }

  function spendSlot(level: number, amount: number) {
    commit({
      spellSlots: spellSlots.map((slot) =>
        slot.level === level
          ? { ...slot, used: Math.min(slot.max, Math.max(0, slot.used + amount)) }
          : slot,
      ),
    });
  }

  function castSpell(spellId: string, requestedSlotLevel?:number, consumeSlot=true, inventoryAfterCast?:Character["inventory"]) {
    const spell = rulesetData?.spells.find((item) => item.id === spellId);

    if (!spell) return;
    if(itemEffectRuntime.blocksAggressiveActions)return;
    const spellTime=spell.castingTime.toLowerCase();
    if ((spellTime.includes("bonus")&&turnEconomy.bonusActionUsed)||(spellTime.includes("reaction")&&turnEconomy.reactionUsed)||(!spellTime.includes("bonus")&&!spellTime.includes("reaction")&&turnEconomy.actionUsed)) return;

    const slotLevel=spell.level===0?0:requestedSlotLevel??getCastableSlotLevels(spell,spellSlots)[0];
    if (spell.level > 0 && consumeSlot) {
      const slot = spellSlots.find((item) => item.level === slotLevel);
      if (!slot || slot.used >= slot.max) return;
    }

    const nextConditions =
      spell.concentration &&
      !activeCharacter.conditions.includes("Concentration")
        ? [...activeCharacter.conditions, "Concentration" as const]
        : activeCharacter.conditions;

    const spellcastingStats=getSpellcastingStatsForSpell(effectiveCharacter,spell,rulesetData);
    const spellAbility=spellcastingStats?.spellcastingAbility??spellcastingAbility;
    const formula=getSpellRollFormula(spell,activeCharacter.level,slotLevel);const rolledTotal=formula?rollFormula(formula):null;const lifeHealing=getLifeDomainHealing(activeCharacter.subclass,activeCharacter.level,slotLevel);const total=rolledTotal!==null&&spell.healingDice?rolledTotal+lifeHealing.healingBonus:rolledTotal;const createdEffect=createSpellEffect(spell,activeCharacter.ruleset,slotLevel);const effectsAfterAction=removeEffectsBrokenBySpellCast(removeFragileItemEffects(activeSpellEffects),Boolean(spell.damageDice));const nextEffects=createdEffect?addSpellEffect(effectsAfterAction,createdEffect):effectsAfterAction;
    commit({
      currentHp:spell.healingDice&&total!==null?Math.min(activeCharacter.maxHp,activeCharacter.currentHp+Math.max(0,total)):activeCharacter.currentHp,
      spellSlots:
        spell.level === 0 || !consumeSlot
          ? spellSlots
          : spellSlots.map((slot) =>
              slot.level === slotLevel
                ? { ...slot, used: slot.used + 1 }
                : slot,
            ),
      conditions: nextConditions,
      activeSpellEffects:nextEffects,
      ...(inventoryAfterCast ? { inventory: inventoryAfterCast } : {}),
    });
    const resolutionRolls:RollResult[]=[];let resolvedDamage=total;if(spell.attackType==="spell-attack"){const dice=rollDice({count:spellTargetMode==="normal"?1:2,sides:20,modifier:0});const attack=resolveAttack(dice.rolls,getSpellAttackBonus(effectiveCharacter,spellAbility),targetAc,spellTargetMode);resolutionRolls.push({id:dice.id,label:`${spell.name} Attack · ${attack.hit?attack.critical?"CRITICAL":"Hit":"Miss"}`,notation:`${spellTargetMode} · [${dice.rolls.join(", ")}] vs AC ${targetAc}`,total:attack.total});if(!attack.hit)resolvedDamage=null}if((spell.attackType==="saving-throw"||spell.saveAbility)&&spell.saveAbility){const dice=rollDice({count:spellTargetMode==="normal"?1:2,sides:20,modifier:0});const save=resolveTargetSave(dice.rolls,targetSaveBonus,getSpellSaveDc(effectiveCharacter,spellAbility),spellTargetMode);const rule=saveDamageRule==="auto"?getDefaultSaveDamageRule(spell):saveDamageRule;if(total!==null)resolvedDamage=resolveSaveDamage(total,save.success,rule);resolutionRolls.push({id:dice.id,label:`${spell.name} · ${spell.saveAbility.toUpperCase()} Save · ${save.success?"Başarılı":"Başarısız"}`,notation:`${spellTargetMode} · [${dice.rolls.join(", ")}] ${formatModifier(targetSaveBonus)} vs DC ${getSpellSaveDc(effectiveCharacter,spellAbility)}`,total:save.total})}if(resolvedDamage!==null)resolutionRolls.push({id:crypto.randomUUID(),label:`${spell.name}${spell.healingDice?" Healing":" Damage"}`,notation:formula!,total:resolvedDamage});if(resolutionRolls.length)setRollHistory(current=>[...resolutionRolls,...current].slice(0,6));setTurnEconomy(current=>spendTurnResource(current,spellTime.includes("bonus")?"bonus-action":spellTime.includes("reaction")?"reaction":"action"));
  }

  function quickRoll(label: string, modifier: number) {
    const result = rollDice({ count: 1, sides: 20, modifier });
    setRollHistory((current) =>
      [
        {
          id: result.id,
          label,
          notation: result.notation,
          total: result.total,
        },
        ...current,
      ].slice(0, 6),
    );
  }

  function resolvedCheck(label:string,modifier:number,kind:"skill"|"save",ability?:AbilityKey){const imposed=kind==="skill"?exhaustionEffects.abilityCheckMode:exhaustionEffects.attackSaveMode;const potionMode=kind==="save"&&ability==="dex"?itemEffectRuntime.dexSaveMode:"normal";const baseMode=combineRollModes(combineRollModes(checkMode,imposed),potionMode);const effectiveMode=kind==="save"&&ability?getAncestrySaveMode(combinedSaveRuntime,ability,baseMode):baseMode;const adjustedModifier=modifier-exhaustionEffects.d20Penalty;const dice=rollDice({count:effectiveMode==="normal"?1:2,sides:20,modifier:0});const chosen=chooseD20(dice.rolls,effectiveMode);const proficient=kind==="skill"&&activeCharacter.skillProficiencies.some(skill=>label.startsWith(skill));const natural=applyReliableTalent(chosen,proficient,activeCharacter.className,activeCharacter.level);const potionBonus=kind==="save"&&itemEffectRuntime.attackSaveBonusDice?rollFormula(itemEffectRuntime.attackSaveBonusDice):0;setRollHistory(current=>[{id:dice.id,label,notation:`${effectiveMode} · [${dice.rolls.join(", ")}] ${natural!==chosen?"· Reliable Talent 10 ":""}${formatModifier(adjustedModifier)}${potionBonus?` + ${potionBonus} potion`:""}`,total:natural+adjustedModifier+potionBonus},...current].slice(0,6))}
  function monkAction(name:string,cost:number,resource:"action"|"bonus-action"){if(!isMonk||conditionEffects.blocksActions||(resource==="action"?turnEconomy.actionUsed:turnEconomy.bonusActionUsed)||!focusPoints||focusPoints.max-focusPoints.used<cost)return;const die=getMartialArtsDie(activeCharacter.level,activeCharacter.ruleset);const attack=rollDice({count:1,sides:20,modifier:getAbilityModifier(activeCharacter.abilities.dex)+getProficiencyBonus(activeCharacter.level)});const damage=rollDice({count:1,sides:die,modifier:getAbilityModifier(activeCharacter.abilities.dex)});commit({resources:activeCharacter.resources.map(item=>item.id==="focus-points"?{...item,used:item.used+cost}:item)});setTurnEconomy(current=>spendTurnResource(current,resource));setRollHistory(current=>[{id:attack.id,label:`${name} Attack`,notation:attack.notation,total:attack.total},{id:damage.id,label:`${name} Damage`,notation:damage.notation,total:damage.total},...current].slice(0,6))}
  function grantBardicInspiration(){if(!bardicInspiration||bardicInspiration.used>=bardicInspiration.max||turnEconomy.bonusActionUsed)return;const result=rollDice({count:1,sides:getBardicInspirationDie(activeCharacter.level),modifier:0});commit({resources:activeCharacter.resources.map(item=>item.id==="bardic-inspiration"?{...item,used:item.used+1}:item)});setTurnEconomy(current=>spendTurnResource(current,"bonus-action"));setRollHistory(current=>[{id:result.id,label:"Bardic Inspiration",notation:result.notation,total:result.total},...current].slice(0,6))}
  function useActionSurge(){if(!actionSurge||actionSurge.used>=actionSurge.max)return;commit({resources:activeCharacter.resources.map(item=>item.id==="action-surge"?{...item,used:item.used+1}:item)});setTurnEconomy(current=>({...current,actionUsed:false,attacksUsed:0}))}
  function useIndomitable(){if(!indomitable||indomitable.used>=indomitable.max)return;const bonus=getIndomitableBonus(activeCharacter.level,activeCharacter.ruleset);const result=rollDice({count:1,sides:20,modifier:bonus});commit({resources:activeCharacter.resources.map(item=>item.id==="indomitable"?{...item,used:item.used+1}:item)});setRollHistory(current=>[{id:result.id,label:"Indomitable Save Reroll",notation:result.notation,total:result.total},...current].slice(0,6))}
  function activateChannelDivinity(mode:"turn"|"spark-heal"|"spark-damage"){if(!channelDivinity||channelDivinity.used>=channelDivinity.max||turnEconomy.actionUsed)return;const rolls:RollResult[]=[];if(mode!=="turn"){const result=rollDice({count:getDivineSparkDice(activeCharacter.level),sides:8,modifier:getAbilityModifier(activeCharacter.abilities.wis)});rolls.push({id:result.id,label:mode==="spark-heal"?"Divine Spark Healing":"Divine Spark Radiant Damage",notation:result.notation,total:result.total})}commit({resources:activeCharacter.resources.map(item=>item.id==="channel-divinity"?{...item,used:item.used+1}:item)});setTurnEconomy(current=>spendTurnResource(current,"action"));setRollHistory(current=>[{id:crypto.randomUUID(),label:mode==="turn"?`Turn Undead · WIS Save DC ${getSpellSaveDc(activeCharacter)}`:"Channel Divinity",notation:"Action",total:getSpellSaveDc(activeCharacter)},...rolls,...current].slice(0,6))}
  function createSorcerySlot(level:number){if(!sorceryPoints)return;const slot=spellSlots.find(item=>item.level===level);const remaining=sorceryPoints.max-sorceryPoints.used;if(!slot||!canCreateSorcerySlot(level,remaining,slot.used>0))return;const cost=getSorcerySlotCost(level)!;commit({spellSlots:spellSlots.map(item=>item.level===level?{...item,used:item.used-1}:item),resources:activeCharacter.resources.map(item=>item.id==="sorcery-points"?{...item,used:item.used+cost}:item)})}
  function convertSlotToSorceryPoints(level:number){if(!sorceryPoints)return;const slot=spellSlots.find(item=>item.level===level);const gain=getPointsFromSlot(level);const remaining=sorceryPoints.max-sorceryPoints.used;if(!slot||slot.used>=slot.max||remaining<=0)return;const actual=Math.min(gain,remaining);commit({spellSlots:spellSlots.map(item=>item.level===level?{...item,used:item.used+1}:item),resources:activeCharacter.resources.map(item=>item.id==="sorcery-points"?{...item,used:item.used-actual}:item)})}
  function applyArcaneRecovery(){if(!arcaneRecovery||arcaneRecovery.used>=arcaneRecovery.max||!arcaneRecoveryLevels.length)return;const counts=new Map<number,number>();arcaneRecoveryLevels.forEach(level=>counts.set(level,(counts.get(level)??0)+1));commit({spellSlots:spellSlots.map(slot=>({...slot,used:Math.max(0,slot.used-(counts.get(slot.level)??0))})),resources:activeCharacter.resources.map(item=>item.id==="arcane-recovery"?{...item,used:item.used+1}:item)});setArcaneRecoveryLevels([])}
  function useFavoredEnemy(){if(!favoredEnemy||favoredEnemy.used>=favoredEnemy.max||turnEconomy.bonusActionUsed)return;commit({resources:activeCharacter.resources.map(item=>item.id==="favored-enemy"?{...item,used:item.used+1}:item),conditions:activeCharacter.conditions.includes("Concentration")?activeCharacter.conditions:[...activeCharacter.conditions,"Concentration"]});setTurnEconomy(current=>spendTurnResource(current,"bonus-action"))}
  function consumeItem(itemId:string){
    const item=rulesetData?.items.find(candidate=>candidate.id===itemId);
    if(!item)return;
    const nextInventory=consumeInventoryItem(activeCharacter.inventory,itemId);
    const scrollSpell=item.tags?.includes("scroll")?rulesetData?.spells.find(candidate=>candidate.name===item.grantedSpellName):undefined;
    if(scrollSpell){castSpell(scrollSpell.id,scrollSpell.level,false,nextInventory);return}
    const damageProfile=getItemDamageProfile(item);
    if(damageProfile){
      const targetMatches=!damageProfile.targetTag||damageProfile.targetTag===magicWeaponTarget;
      const rolledDamage=targetMatches?rollFormula(damageProfile.formula):0;
      let resolvedDamage=rolledDamage;
      const damageRolls:RollResult[]=[];
      if(damageProfile.saveAbility&&damageProfile.saveDc){
        const dice=rollDice({count:spellTargetMode==="normal"?1:2,sides:20,modifier:0});
        const save=resolveTargetSave(dice.rolls,targetSaveBonus,damageProfile.saveDc,spellTargetMode);
        resolvedDamage=resolveSaveDamage(rolledDamage,save.success,damageProfile.saveRule);
        damageRolls.push({id:dice.id,label:`${item.name} · ${damageProfile.saveAbility.toUpperCase()} Save · ${save.success?"Başarılı":"Başarısız"}`,notation:`${spellTargetMode} · [${dice.rolls.join(", ")}] ${formatModifier(targetSaveBonus)} vs DC ${damageProfile.saveDc}`,total:save.total});
      }
      damageRolls.push({id:crypto.randomUUID(),label:`${item.name} · ${damageProfile.damageType} Damage${targetMatches?"":" · Hedef türü eşleşmedi"}`,notation:damageProfile.formula,total:resolvedDamage});
      setRollHistory(current=>[...damageRolls,...current].slice(0,6));
    }
    const formula=getItemHealingFormula(item);
    let currentHp=activeCharacter.currentHp;
    if(formula){const total=rollFormula(formula);currentHp=Math.min(activeCharacter.maxHp,currentHp+total);setRollHistory(current=>[{id:crypto.randomUUID(),label:`${item.name} Healing`,notation:formula,total},...current].slice(0,6))}
    const effect=createItemEffect(item);
    const itemTempHp=getItemTempHp(item);
    const restoration=getItemRestoration(item);
    const cured=new Set(restoration.curesConditions);
    const conditionDurations={...(activeCharacter.conditionDurations??{})};
    restoration.curesConditions.forEach(condition=>delete conditionDurations[condition as CharacterCondition]);
    commit({
      currentHp,
      tempHp:Math.max(activeCharacter.tempHp,itemTempHp),
      inventory:nextInventory,
      activeSpellEffects:effect?[...activeSpellEffects,effect]:activeSpellEffects,
      conditions:activeCharacter.conditions.filter(condition=>!cured.has(condition)),
      conditionDurations,
      exhaustion:restoration.clearsExhaustion?0:activeCharacter.exhaustion,
      hitDice:restoration.restoresHitDice?resetHitDice(hitDice):hitDice,
    })
  }
  function toggleAttunement(itemId:string){const item=rulesetData?.items.find(candidate=>candidate.id===itemId);if(item)commit({inventory:toggleItemAttunement(activeCharacter.inventory,item)})}
  function spendMagicItemCharge(itemId:string){const item=rulesetData?.items.find(candidate=>candidate.id===itemId);if(!item)return;const cost=item.chargeCost??1;const entry=activeCharacter.inventory.find(candidate=>candidate.itemId===itemId);if(!entry||item.requiresAttunement&&!entry.attuned||!item.charges||item.charges-(entry.chargesUsed??0)<cost)return;if(item.id==="pearl-of-power"){const nextSlots=recoverHighestSpentSpellSlot(spellSlots);if(nextSlots===spellSlots)return;commit({inventory:spendItemCharge(activeCharacter.inventory,item,cost),spellSlots:nextSlots});return}commit({inventory:spendItemCharge(activeCharacter.inventory,item,cost)});const spell=rulesetData?.spells.find(candidate=>candidate.name===item.grantedSpellName);if(spell)castSpell(spell.id,spell.level,false)}

  function handleFeatAction(action:FeatAction){const used=featActionUses[action.id]??0;if(used>=action.maxUses)return;if(action.type==="action"&&turnEconomy.actionUsed||action.type==="bonus-action"&&turnEconomy.bonusActionUsed||action.type==="reaction"&&turnEconomy.reactionUsed)return;const tempHp=action.id==="inspiring-leader"?getInspiringLeaderTempHp(activeCharacter.level,getAbilityModifier(effectiveCharacter.abilities.cha)):activeCharacter.tempHp;if(action.maxUses<99)setFeatActionUses(current=>({...current,[action.id]:used+1}));commit({tempHp:Math.max(activeCharacter.tempHp,tempHp)});setTurnEconomy(current=>spendTurnResource(current,action.type));setRollHistory(current=>[{id:crypto.randomUUID(),label:`Feat · ${action.name}`,notation:action.summary,total:action.id==="inspiring-leader"?tempHp:0},...current].slice(0,6))}

  function handleSubclassAction(action:SubclassRuntimeAction){if(!canUseSubclassAction(action,activeCharacter.resources))return;if(action.type==="action"&&turnEconomy.actionUsed||action.type==="bonus-action"&&turnEconomy.bonusActionUsed||action.type==="reaction"&&turnEconomy.reactionUsed)return;const resources=spendSubclassActionResource(action,activeCharacter.resources);if(action.id==="tides-of-chaos")setCheckMode("advantage");const damage=action.id==="radiance-of-dawn"?rollDice({count:Math.max(2,Math.ceil(activeCharacter.level/2)),sides:10,modifier:getAbilityModifier(effectiveCharacter.abilities.wis)}):null;const healing=action.id==="preserve-life"?getPreserveLifeHealing(activeCharacter.level,activeCharacter.currentHp,activeCharacter.maxHp):0;commit({resources,currentHp:healing?Math.min(activeCharacter.maxHp,activeCharacter.currentHp+healing):activeCharacter.currentHp});setTurnEconomy(current=>spendTurnResource(current,action.type));setRollHistory(current=>[{id:damage?.id??crypto.randomUUID(),label:`${activeCharacter.subclass} · ${action.name}`,notation:damage?.notation??(healing?`+${healing} HP`:action.type),total:damage?.total??healing},...current].slice(0,6))}

  function weaponAttack(weapon: (typeof equippedItems.weapons)[number]) {
    if (conditionEffects.blocksActions || exhaustionEffects.dead || turnEconomy.actionUsed || itemEffectRuntime.blocksAggressiveActions) return;
    const legality=getEquipmentLegality(weapon,classProfiles,effectiveCharacter.abilities);
    const ammunitionId=findAmmunitionId(weapon,rulesetData?.items??[]);
    const inventoryAfterAmmunition=consumeAmmunition(activeCharacter.inventory,ammunitionId);
    if(ammunitionId&&inventoryAfterAmmunition===null)return;
    const conditionMode = combineRollModes(conditionEffects.attackMode, exhaustionEffects.attackSaveMode);
    const effectiveMode = combineRollModes(combineRollModes(combineRollModes(combineRollModes(attackMode, conditionMode), itemEffectRuntime.attackMode), spellDefenseMovementRuntime.attackMode),masteryVexReady?"advantage":"normal");
    const potionAttackBonus = itemEffectRuntime.attackSaveBonusDice ? rollFormula(itemEffectRuntime.attackSaveBonusDice) : 0;
    const modifier = getWeaponAttackBonus(effectiveCharacter, weapon) - (legality.proficient?0:getProficiencyBonus(activeCharacter.level)) - exhaustionEffects.d20Penalty + potionAttackBonus - (powerAttack&&advancedFeatRuntime.powerAttack?5:0);
    const dice = rollDice({ count: effectiveMode === "normal" ? 1 : 2, sides: 20, modifier: 0 });
    const baseAttack = resolveAttack(dice.rolls, modifier, targetAc, effectiveMode);
    const attack = {...baseAttack,critical:baseAttack.hit&&baseAttack.naturalRoll>=subclassRuntime.criticalThreshold};
    const masteryOutcome=resolveWeaponMastery({weapon,ruleset:activeCharacter.ruleset,masteredWeaponIds:activeCharacter.masteredWeaponIds??[],hit:attack.hit,abilityModifier:getWeaponAbilityModifier(effectiveCharacter,weapon)});
    const results: RollResult[] = [{ id: dice.id, label: `${weapon.name} · ${attack.hit ? attack.critical ? "CRITICAL" : "Hit" : "Miss"}`, notation: `${effectiveMode} · [${dice.rolls.join(", ")}] ${formatModifier(modifier)} vs AC ${targetAc}`, total: attack.total }];
    if (attack.hit) {
      const formula = getCriticalDamageFormula(getWeaponDamageSummary(effectiveCharacter, weapon), attack.critical);
      if (formula) {
        const properties=weapon.properties?.map(property=>property.toLowerCase())??[];
        const abilityModifier=getWeaponAbilityModifier(effectiveCharacter,weapon);
        const adjustedFormula={...formula,modifier:getOffhandDamageModifier(formula.modifier,abilityModifier,offhandAttack,activeCharacter.fightingStyleIds?.includes("two-weapon-fighting")??false)};
        const greatWeaponFighting=(activeCharacter.fightingStyleIds?.includes("great-weapon-fighting")??false)&&properties.some(property=>property.includes("two-handed"));
        const damage=rollStyledWeaponDamage(adjustedFormula,greatWeaponFighting);
        results.push({id:crypto.randomUUID(),label:`${weapon.name} Damage${attack.critical?" · Critical":""}${offhandAttack?" · Off-hand":""}`,notation:damage.notation,total:damage.total});
        if(powerAttack&&advancedFeatRuntime.powerAttack)results.push({id:crypto.randomUUID(),label:"Power Attack Damage",notation:"Feat +10",total:10});
        if(attack.critical&&ancestryRuntime.criticalExtraDice){const savage=rollDice({count:ancestryRuntime.criticalExtraDice,sides:formula.sides,modifier:0});results.push({id:savage.id,label:"Savage Attacks · Critical Die",notation:savage.notation,total:savage.total})}
      }
      for (const extra of getMagicWeaponExtraDamage(weapon, magicWeaponTarget, attack.critical)) { const total = rollFormula(extra.formula); results.push({ id: crypto.randomUUID(), label: `${weapon.name} · ${extra.damageType} ${extra.source === "critical" ? "Critical " : ""}Damage`, notation: extra.formula, total }); }
      if (itemEffectRuntime.weaponDamageDice) { const growth = rollFormula(itemEffectRuntime.weaponDamageDice); results.push({ id: crypto.randomUUID(), label: "Potion of Growth Damage", notation: itemEffectRuntime.weaponDamageDice, total: growth }); }
      if (itemEffectRuntime.weaponDamagePenaltyDice) { const reduction = rollFormula(itemEffectRuntime.weaponDamagePenaltyDice); results.push({ id: crypto.randomUUID(), label: "Potion of Diminution Damage", notation: `-${itemEffectRuntime.weaponDamagePenaltyDice}`, total: -reduction }); }
      const sneakAllowed = isRogue && sneakAttackEnabled && canUseSneakAttack({ level: activeCharacter.level, weapon, usedThisTurn: sneakAttackUsed, hasAdvantage: effectiveMode === "advantage", hasDisadvantage: effectiveMode === "disadvantage", allyAdjacent: sneakAllyAdjacent });
      if (sneakAllowed) { const sneak = rollDice({ count: getSneakAttackDice(activeCharacter.level) * (attack.critical ? 2 : 1), sides: 6, modifier: 0 }); results.push({ id: sneak.id, label: `Sneak Attack${attack.critical ? " · Critical" : ""}`, notation: sneak.notation, total: sneak.total }); setSneakAttackUsed(true); }
    }
    if(masteryOutcome.grazeDamage)results.push({id:crypto.randomUUID(),label:`${weapon.name} · Graze Damage`,notation:"Ability modifier",total:masteryOutcome.grazeDamage});
    if(masteryOutcome.note)results.push({id:crypto.randomUUID(),label:`Weapon Mastery · ${masteryOutcome.mastery}`,notation:masteryOutcome.note,total:0});
    setMasteryVexReady(masteryOutcome.grantsVex);
    const effectsAfterAttack = removeEffectsBrokenByAttack(removeFragileItemEffects(activeSpellEffects));
    if (effectsAfterAttack.length !== activeSpellEffects.length||inventoryAfterAmmunition!==activeCharacter.inventory) commit({ activeSpellEffects: effectsAfterAttack,inventory:inventoryAfterAmmunition??activeCharacter.inventory });
    setTurnEconomy(current => spendAttack(current, attacksPerAction));
    setRollHistory(current => [...results, ...current].slice(0, 6));
  }

  function unarmedStyleAttack(){
    if(turnEconomy.actionUsed||conditionEffects.blocksActions)return;
    const abilityModifier=Math.max(getAbilityModifier(effectiveCharacter.abilities.str),getAbilityModifier(effectiveCharacter.abilities.dex));
    const modifier=abilityModifier+getProficiencyBonus(activeCharacter.level);
    const attack=rollDice({count:attackMode==="normal"?1:2,sides:20,modifier:0});
    const resolved=resolveAttack(attack.rolls,modifier,targetAc,attackMode);
    const die=!equippedItems.weapons.length&&!equippedItems.shield?8:6;
    const damage=resolved.hit?rollDice({count:resolved.critical?2:1,sides:die,modifier:abilityModifier}):null;
    setTurnEconomy(current=>spendAttack(current,attacksPerAction));
    setRollHistory(current=>[{id:attack.id,label:`Unarmed Strike · ${resolved.hit?resolved.critical?"CRITICAL":"Hit":"Miss"}`,notation:`${attackMode} · ${formatModifier(modifier)} vs AC ${targetAc}`,total:resolved.total},...(damage?[{id:damage.id,label:"Unarmed Fighting Damage",notation:damage.notation,total:damage.total}]:[]),...current].slice(0,6));
  }
  function handleDefensiveFightingStyle(style:"protection"|"interception"){
    if(turnEconomy.reactionUsed)return;
    const reduction=style==="interception"?getInterceptionReduction(getProficiencyBonus(activeCharacter.level)):0;
    setTurnEconomy(current=>spendTurnResource(current,"reaction"));
    setRollHistory(current=>[{id:crypto.randomUUID(),label:style==="protection"?"Protection · Ally attack disadvantage":"Interception · Damage Reduction",notation:style==="protection"?"Reaction":`1d10 + PB`,total:reduction},...current].slice(0,6));
  }

  function shortRest(die: number) {
    const pool = hitDice.find((item) => item.die === die);
    if (!pool || pool.used >= pool.max) return;

    const result = rollDice({
      count: 1,
      sides: die,
      modifier: getAbilityModifier(effectiveCharacter.abilities.con),
    });

    commit({
      currentHp: Math.min(
        activeCharacter.maxHp,
        activeCharacter.currentHp + Math.max(0, result.total),
      ),
      hitDice: hitDice.map((item) =>
        item.die === die ? { ...item, used: item.used + 1 } : item,
      ),
      resources: recoverHomebrewCharacterResources({...activeCharacter,resources:activeCharacter.resources.map(resource=>resource.recovery==="short"&&!resource.unlimited?{...resource,used:Math.max(0,resource.used-(resource.shortRecoveryAmount??resource.max))}:resource)},homebrewPackages,"short-rest"),
      spellSlots: activeCharacter.className.trim().toLowerCase()==="warlock"?resetSpellSlots(spellSlots):spellSlots,
      pactMagicSlots:resetSpellSlots(pactMagicSlots),
    });

    setRollHistory((current) =>
      [
        {
          id: result.id,
          label: `Short Rest d${die}`,
          notation: result.notation,
          total: Math.max(0, result.total),
        },
        ...current,
      ].slice(0, 6),
    );
  }

  function longRest() {
    commit({
      currentHp: activeCharacter.maxHp,
      tempHp: 0,
      spellSlots: resetSpellSlots(spellSlots),
      pactMagicSlots:resetSpellSlots(pactMagicSlots),
      hitDice: resetHitDice(hitDice),
      deathSaves: resetDeathSaves(),
      exhaustion: Math.max(0, (activeCharacter.exhaustion ?? 0) - 1),
      conditionDurations: {},
      conditions: activeCharacter.conditions.filter((item) => item === "Cursed"),
      resources: recoverHomebrewCharacterResources({...activeCharacter,resources:activeCharacter.resources.map(resource=>resource.id.startsWith("homebrew:")?resource:{...resource,used:0})},homebrewPackages,"long-rest"),
      usedArcanumSpellIds: [],
      activeSpellEffects: [],
      inventory: recoverItemCharges(activeCharacter.inventory, rulesetData?.items ?? []),
    });
    setLuckyUsed(0);
  }

  const hpPercent = Math.max(
    0,
    Math.min(100, (activeCharacter.currentHp / activeCharacter.maxHp) * 100),
  );

  return (
    <PageShell
      eyebrow="Table Mode"
      title="Play Mode"
      description="Masada lazım olan şeyler. Geri kalanı karakter sayfasında usulca bekliyor."
    >
      <div className={`play-mode-v1 ${isFocusMode ? "focus-mode" : ""}`}>
        <header className="play-mode-toolbar">
          <label>
            Aktif karakter
            <select
              value={activeCharacter.id}
              onChange={(event) => {
                setSelectedCharacterId(event.target.value);
                setSearchParams({ character: event.target.value }, { replace: true });
              }}
            >
              {characters.map((item) => (
                <option value={item.id} key={item.id}>
                  {item.name} · Lv. {item.level} {item.className}
                </option>
              ))}
            </select>
          </label>

          <button onClick={() => setIsFocusMode((current) => !current)}>
            {isFocusMode ? "Normal Görünüm" : "Odak Modu"}
          </button>
        </header>

        <section className={`play-readiness-card ${readiness.status}`}>
          <div>
            <span className="mini-label">Playable Character Check</span>
            <strong>{readiness.status === "ready" ? t("play.ready","Karakter masaya hazır") : t("play.score",`Hazırlık skoru: ${readiness.score}%`,{score:readiness.score})}</strong>
            <p>{readiness.status === "ready" ? t("play.readyDetail","HP, progression, seçimler, büyüler ve ekipman bağlantıları oynanabilir durumda.") : t("play.errors",`${readiness.issues.filter((issue) => issue.severity === "error").length} zorunlu düzeltme var.`,{count:readiness.issues.filter(issue=>issue.severity==="error").length})}</p>
          </div>
          <div className="play-readiness-actions">
            {readiness.issues.filter((issue) => issue.severity === "warning").length ? <span>{readiness.issues.filter((issue) => issue.severity === "warning").length} öneri</span> : null}
            <NavLink to={`/characters/${activeCharacter.id}/edit`}>{readiness.status === "ready" ? t("play.edit","Karakteri düzenle") : t("play.fix","Eksikleri düzelt")}</NavLink>
          </div>
        </section>

        <section className="play-mode-hero">
          <div>
            <span className="mini-label">{activeCharacter.playerName || "Player"}</span>
            <h2>{activeCharacter.name}</h2>
            <p>
              Level {activeCharacter.level} {activeCharacter.race} {activeCharacter.className}
            </p>
          </div>

          <div className="play-mode-core-stats">
            <div><span>AC</span><strong>{armorClass}</strong></div>
            <div><span>Init</span><strong>{formatModifier(getInitiative(effectiveCharacter)+featRuntime.alertInitiativeBonus+subclassRuntime.initiativeBonus)}</strong></div>
            <div><span>Prof</span><strong>+{getProficiencyBonus(activeCharacter.level)}</strong></div>
            <div><span>Save DC</span><strong>{getSpellSaveDc(effectiveCharacter,spellcastingAbility)}</strong></div>
            <div><span>Spell Atk</span><strong>{formatModifier(getSpellAttackBonus(effectiveCharacter,spellcastingAbility))}</strong></div>
          </div>
        </section>

        <div className="play-mode-grid">
          <section className="play-mode-card"><div className="play-mode-section-head"><div><span className="mini-label">Equipment Runtime</span><h2>{inventoryWeight.toFixed(1)} / {encumbrance.capacity} lb.</h2></div><strong>{encumbrance.overloaded?"Overloaded":encumbrance.encumbered?"Encumbered":"Normal"}</strong></div><div className="condition-rule-summary">{classLevels.map(item=><small key={item.className}>{item.className} {item.level}</small>)}{armorLegality?.issues.map(issue=><small key={issue}>{equippedItems.armor?.name}: {issue}</small>)}{armorLegality?.stealthDisadvantage&&!advancedFeatRuntime.ignoreMediumArmorStealth?<small>Armor: Stealth disadvantage</small>:null}{mediumArmorMasterBonus?<small>Medium Armor Master: AC +1, Stealth disadvantage ignored.</small>:null}{encumbrance.speedPenalty?<small>Encumbrance speed −{encumbrance.speedPenalty} ft.</small>:null}<small>Multiclass attack cap: {attacksPerAction} / Action</small></div></section>
          {selectedFeats.length?<section className="play-mode-card"><div className="play-mode-section-head"><div><span className="mini-label">Advanced Feat Runtime</span><h2>{selectedFeats.length} feat bağlı</h2></div><strong>{advancedFeatRuntime.actions.length} eylem</strong></div>{advancedFeatRuntime.powerAttack?<label className="rage-resistance-toggle"><input type="checkbox" checked={powerAttack} onChange={event=>setPowerAttack(event.target.checked)}/> Power Attack · attack −5 / damage +10</label>:null}{advancedFeatRuntime.actions.length?<div className="play-mode-big-buttons">{advancedFeatRuntime.actions.map(action=>{const used=featActionUses[action.id]??0;return <button type="button" key={action.id} disabled={used>=action.maxUses||(action.type==="action"&&turnEconomy.actionUsed)||(action.type==="bonus-action"&&turnEconomy.bonusActionUsed)||(action.type==="reaction"&&turnEconomy.reactionUsed)} onClick={()=>handleFeatAction(action)}>{action.name} · {action.type}</button>})}</div>:null}<div className="condition-rule-summary">{advancedFeatRuntime.armorClassBonus?<small>Dual Wielder AC +{advancedFeatRuntime.armorClassBonus}</small>:null}{advancedFeatRuntime.concentrationAdvantage?<small>Concentration save advantage</small>:null}{advancedFeatRuntime.ignoresLoading?<small>Crossbow loading restriction ignored</small>:null}{advancedFeatRuntime.spellRangeMultiplier>1?<small>Spell attack range ×{advancedFeatRuntime.spellRangeMultiplier}</small>:null}{advancedFeatRuntime.mediumArmorDexCap>2?<small>Medium Armor DEX cap +{advancedFeatRuntime.mediumArmorDexCap}; Stealth disadvantage ignored.</small>:null}{advancedFeatRuntime.elementalResistanceBypass?<small>Elemental Adept: selected element resistance ignored.</small>:null}{advancedFeatRuntime.damageRerollTypes.length?<small>Damage reroll: {advancedFeatRuntime.damageRerollTypes.join(", ")}</small>:null}{advancedFeatRuntime.grantsRitualCasting?<small>Ritual Caster spellbook access enabled.</small>:null}{advancedFeatRuntime.grantsExpertise?<small>Skill Expert: selected proficiency gains Expertise.</small>:null}{advancedFeatRuntime.notes.map(note=><small key={note}>{note}</small>)}</div></section>:null}
          <section className="play-mode-card"><div className="play-mode-section-head"><div><span className="mini-label">{activeCharacter.ruleset==="dnd_2024"?"Species":"Race"} Runtime</span><h2>{activeCharacter.race}{activeCharacter.subrace?` · ${activeCharacter.subrace}`:""}</h2></div><strong>{ancestryRuntime.darkvision?`${ancestryRuntime.darkvision} ft. görüş`:"Normal görüş"}</strong></div><div className="condition-rule-summary"><small>Speed {effectiveSpeed} ft.{ancestryRuntime.speedBonus?` · ancestry +${ancestryRuntime.speedBonus}`:""}</small>{ancestryRuntime.damageResistances.length?<small>Resistance: {ancestryRuntime.damageResistances.join(", ")}</small>:null}{ancestryRuntime.saveAdvantages.length?<small>Save advantage: {ancestryRuntime.saveAdvantages.map(item=>item.toUpperCase()).join(", ")}</small>:null}{ancestryRuntime.maxHpBonus?<small>Dwarven Toughness katkısı: +{ancestryRuntime.maxHpBonus} Max HP</small>:null}{ancestryRuntime.features.map(feature=><small key={feature}>{feature}</small>)}</div></section>
          {capstoneSummary?<section className="play-mode-card"><div className="play-mode-section-head"><div><span className="mini-label">Level 20</span><h2>Class Capstone Runtime</h2></div><strong>Aktif</strong></div><div className="condition-rule-summary"><small>{capstoneSummary}</small></div></section>:null}
          {selectedSubclass?<section className="play-mode-card"><div className="play-mode-section-head"><div><span className="mini-label">Subclass Runtime</span><h2>{selectedSubclass.name}</h2></div><strong>{subclassRuntime.unlockedFeatures.length}/{selectedSubclass.features.length} açık</strong></div>{subclassRuntime.actions.length?<div className="play-mode-big-buttons">{subclassRuntime.actions.map(action=><button type="button" key={action.id} disabled={!canUseSubclassAction(action,activeCharacter.resources)||(action.type==="action"&&turnEconomy.actionUsed)||(action.type==="bonus-action"&&turnEconomy.bonusActionUsed)||(action.type==="reaction"&&turnEconomy.reactionUsed)} onClick={()=>handleSubclassAction(action)}>{action.name} · {action.type}</button>)}</div>:null}<div className="condition-rule-summary">{subclassRuntime.criticalThreshold<20?<small>Critical threshold: {subclassRuntime.criticalThreshold}–20</small>:null}{subclassRuntime.attacksPerActionMinimum>1?<small>Extra Attack: {subclassRuntime.attacksPerActionMinimum} attack / Action</small>:null}{subclassRuntime.armorClassFloor?<small>Unarmored AC floor: {subclassRuntime.armorClassFloor}</small>:null}{subclassRuntime.damageResistances.length?<small>Resistance: {subclassRuntime.damageResistances.join(", ")}</small>:null}{subclassRuntime.notes.map(note=><small key={note}>{note}</small>)}</div></section>:null}
          <section className="play-mode-card turn-economy-card"><div className="play-mode-section-head"><div><span className="mini-label">Current Turn</span><h2>Action Economy</h2></div><button type="button" onClick={()=>{setTurnEconomy(createTurnEconomy());setSneakAttackUsed(false)}}>Yeni Tur</button></div><div className="turn-resource-grid"><button className={turnEconomy.actionUsed?"spent":""} onClick={()=>setTurnEconomy(current=>spendTurnResource(current,"action"))}>Action <small>{turnEconomy.actionUsed?"Kullanıldı":"Hazır"}</small></button><button className={turnEconomy.bonusActionUsed?"spent":""} onClick={()=>setTurnEconomy(current=>spendTurnResource(current,"bonus-action"))}>Bonus Action <small>{turnEconomy.bonusActionUsed?"Kullanıldı":"Hazır"}</small></button><button className={turnEconomy.reactionUsed?"spent":""} onClick={()=>setTurnEconomy(current=>spendTurnResource(current,"reaction"))}>Reaction <small>{turnEconomy.reactionUsed?"Kullanıldı":"Hazır"}</small></button></div><div className="movement-console"><span>Movement {turnEconomy.movementUsed} / {effectiveSpeed} ft.</span>{[5,10,15].map(feet=><button type="button" key={feet} disabled={turnEconomy.movementUsed>=effectiveSpeed} onClick={()=>setTurnEconomy(current=>spendMovement(current,feet,effectiveSpeed))}>+{feet}</button>)}</div><small>Attack {turnEconomy.attacksUsed} / {attacksPerAction} · Spell casting time action kaynağını otomatik harcar.</small></section>
          {activeCharacter.fightingStyleIds?.length?<section className="play-mode-card"><div className="play-mode-section-head"><div><span className="mini-label">Fighting Styles</span><h2>Combat Style Runtime</h2></div><strong>{activeCharacter.fightingStyleIds.length} aktif</strong></div><div className="play-mode-big-buttons">{activeCharacter.fightingStyleIds.includes("unarmed-fighting")?<button type="button" disabled={turnEconomy.actionUsed} onClick={unarmedStyleAttack}>Unarmed Strike</button>:null}{activeCharacter.fightingStyleIds.includes("protection")?<button type="button" disabled={turnEconomy.reactionUsed} onClick={()=>handleDefensiveFightingStyle("protection")}>Protection · Reaction</button>:null}{activeCharacter.fightingStyleIds.includes("interception")?<button type="button" disabled={turnEconomy.reactionUsed} onClick={()=>handleDefensiveFightingStyle("interception")}>Interception · Reaction</button>:null}</div><div className="condition-rule-summary">{activeCharacter.fightingStyleIds.includes("great-weapon-fighting")?<small>Great Weapon Fighting: 1–2 damage die bir kez reroll.</small>:null}{activeCharacter.fightingStyleIds.includes("two-weapon-fighting")?<small>Two-Weapon Fighting: off-hand ability damage korunur.</small>:null}{activeCharacter.fightingStyleIds.includes("blind-fighting")?<small>Blind Fighting: 10 ft. blindsight.</small>:null}</div></section>:null}
          {isRogue?<section className="play-mode-card"><div className="play-mode-section-head"><div><span className="mini-label">Rogue Combat</span><h2>Sneak Attack · {getSneakAttackDice(activeCharacter.level)}d6</h2></div><strong>{sneakAttackUsed?"Bu tur kullanıldı":"Hazır"}</strong></div><div className="rogue-toggle-grid"><label><input type="checkbox" checked={sneakAttackEnabled} onChange={event=>setSneakAttackEnabled(event.target.checked)}/> İsabette uygula</label><label><input type="checkbox" checked={sneakAllyAdjacent} onChange={event=>setSneakAllyAdjacent(event.target.checked)}/> Hedefin yanında müttefik var</label></div>{rogueFeatures.cunningAction?<div className="play-mode-big-buttons">{["Dash","Disengage","Hide"].map(action=><button type="button" key={action} disabled={turnEconomy.bonusActionUsed} onClick={()=>setTurnEconomy(current=>spendTurnResource(current,"bonus-action"))}>{action}</button>)}</div>:null}<div className="condition-rule-summary">{rogueFeatures.uncannyDodge?<small>Uncanny Dodge: görülen saldırıya Reaction ile yarım hasar.</small>:null}{rogueFeatures.evasion?<small>Evasion: DEX save hasarı başarıda 0, başarısızlıkta yarım.</small>:null}{rogueFeatures.reliableTalent?<small>Reliable Talent: proficient check d20 sonucu minimum 10.</small>:null}{rogueFeatures.elusive?<small>Elusive: incapacitated değilken saldırılar sana advantage alamaz.</small>:null}</div></section>:null}
          {isBarbarian?<section className="play-mode-card"><div className="play-mode-section-head"><div><span className="mini-label">Barbarian Combat</span><h2>Rage · +{getRageDamageBonus(activeCharacter.level)} damage</h2></div><strong>{isRaging?"Raging":"Hazır değil"}</strong></div><div className="rogue-toggle-grid"><label><input type="checkbox" checked={recklessAttack} disabled={!barbarianFeatures.recklessAttack} onChange={event=>setRecklessAttack(event.target.checked)}/> Reckless Attack</label>{activeCharacter.ruleset==="dnd_2024"?<span>Brutal Strike {getBrutalStrike(activeCharacter.level,"dnd_2024").dice}d10 · {getBrutalStrike(activeCharacter.level,"dnd_2024").effectCount} effect</span>:<span>Brutal Critical +{getBrutalCriticalExtraDice(activeCharacter.level,activeCharacter.ruleset)} die</span>}</div><div className="condition-rule-summary"><small>STR melee uygun silah: {equippedItems.weapons.some((weapon)=>isRageDamageWeapon(weapon,activeCharacter.ruleset==="dnd_2024"?"dnd_2024":"dnd_2014","str"))?"var":"yok"}</small>{barbarianFeatures.dangerSense?<small>Danger Sense: DEX save advantage.</small>:null}{barbarianFeatures.relentlessRage?<small>Relentless Rage: başarılı CON save sonrası ${getRelentlessRageRecoveryHp(activeCharacter.level,activeCharacter.ruleset==="dnd_2024"?"dnd_2024":"dnd_2014")} HP.</small>:null}{barbarianFeatures.persistentRage?<small>Persistent Rage etkin.</small>:null}</div></section>:null}
          {isMonk?<section className="play-mode-card"><div className="play-mode-section-head"><div><span className="mini-label">Monk Combat</span><h2>Martial Arts · d{getMartialArtsDie(activeCharacter.level,activeCharacter.ruleset)}</h2></div><strong>{focusPoints?`${focusPoints.max-focusPoints.used} / ${focusPoints.max} ${activeCharacter.ruleset==="dnd_2024"?"Focus":"Ki"}`:"Kaynak yok"}</strong></div><div className="play-mode-big-buttons"><button type="button" disabled={turnEconomy.actionUsed} onClick={()=>monkAction("Unarmed Strike",0,"action")}>Unarmed Strike</button>{monkFeatures.flurry?<button type="button" disabled={turnEconomy.bonusActionUsed||!focusPoints||focusPoints.used>=focusPoints.max} onClick={()=>monkAction("Flurry of Blows",1,"bonus-action")}>Flurry · 1</button>:null}{monkFeatures.patientDefense?<button type="button" disabled={turnEconomy.bonusActionUsed||!focusPoints||focusPoints.used>=focusPoints.max} onClick={()=>monkAction("Patient Defense",1,"bonus-action")}>Patient Defense · 1</button>:null}{monkFeatures.stepOfWind?<button type="button" disabled={turnEconomy.bonusActionUsed||!focusPoints||focusPoints.used>=focusPoints.max} onClick={()=>monkAction("Step of the Wind",1,"bonus-action")}>Step of Wind · 1</button>:null}</div><div className="condition-rule-summary"><small>Unarmored Movement +{getUnarmoredMovementBonus(activeCharacter.level)} ft.</small>{monkFeatures.deflectAttacks?<small>Deflect Attacks aktif.</small>:null}{monkFeatures.stunningStrike?<small>Stunning Strike: isabette 1 Focus/Ki.</small>:null}{monkFeatures.evasion?<small>Evasion aktif.</small>:null}{monkFeatures.diamondSoul?<small>Diamond Soul / Disciplined Survivor aktif.</small>:null}</div></section>:null}
          {isBard?<section className="play-mode-card"><div className="play-mode-section-head"><div><span className="mini-label">Bard Support</span><h2>Bardic Inspiration · d{getBardicInspirationDie(activeCharacter.level)}</h2></div><strong>{bardicInspiration?`${bardicInspiration.max-bardicInspiration.used} / ${bardicInspiration.max} kaldı`:"Kaynak yok"}</strong></div><button type="button" disabled={!bardicInspiration||bardicInspiration.used>=bardicInspiration.max||turnEconomy.bonusActionUsed} onClick={grantBardicInspiration}>Inspiration Ver · Bonus Action</button><div className="condition-rule-summary"><small>Recovery: {getInspirationRecovery(activeCharacter.level)} rest</small>{bardFeatures.songOfRest?<small>Song of Rest +d{bardFeatures.songOfRest}</small>:null}{bardFeatures.fontOfInspiration?<small>Font of Inspiration aktif.</small>:null}{bardFeatures.countercharm?<small>Countercharm aktif.</small>:null}{bardFeatures.magicalSecrets?<small>Magical Secrets aktif.</small>:null}{bardFeatures.superiorInspiration?<small>Superior Inspiration aktif.</small>:null}</div></section>:null}
          {isFighter?<section className="play-mode-card"><div className="play-mode-section-head"><div><span className="mini-label">Fighter Combat</span><h2>{fighterFeatures.extraAttack} Attack / Action</h2></div></div><div className="play-mode-big-buttons"><button type="button" disabled={!secondWind||secondWind.used>=secondWind.max||turnEconomy.bonusActionUsed} onClick={()=>{executeClassAction("second-wind");setTurnEconomy(current=>spendTurnResource(current,"bonus-action"))}}>Second Wind</button>{fighterFeatures.actionSurge?<button type="button" disabled={!actionSurge||actionSurge.used>=actionSurge.max} onClick={useActionSurge}>Action Surge</button>:null}{fighterFeatures.indomitable?<button type="button" disabled={!indomitable||indomitable.used>=indomitable.max} onClick={useIndomitable}>Indomitable</button>:null}</div><div className="condition-rule-summary">{fighterFeatures.tacticalMind?<small>Tactical Mind aktif.</small>:null}{fighterFeatures.tacticalMaster?<small>Tactical Master aktif.</small>:null}{fighterFeatures.studiedAttacks?<small>Studied Attacks aktif.</small>:null}</div></section>:null}
          {isCleric&&clericFeatures.channelDivinity?<section className="play-mode-card"><div className="play-mode-section-head"><div><span className="mini-label">Cleric Divinity</span><h2>Channel Divinity</h2></div><strong>{channelDivinity?`${channelDivinity.max-channelDivinity.used} / ${channelDivinity.max} kaldı`:"Kaynak yok"}</strong></div><div className="play-mode-big-buttons"><button type="button" disabled={!channelDivinity||channelDivinity.used>=channelDivinity.max||turnEconomy.actionUsed} onClick={()=>activateChannelDivinity("turn")}>Turn Undead</button>{clericFeatures.divineSpark?<><button type="button" disabled={!channelDivinity||channelDivinity.used>=channelDivinity.max||turnEconomy.actionUsed} onClick={()=>activateChannelDivinity("spark-heal")}>Divine Spark Heal</button><button type="button" disabled={!channelDivinity||channelDivinity.used>=channelDivinity.max||turnEconomy.actionUsed} onClick={()=>activateChannelDivinity("spark-damage")}>Divine Spark Damage</button></>:null}</div><div className="condition-rule-summary">{clericFeatures.destroyUndead?<small>Destroy Undead: CR {clericFeatures.destroyUndead} ve altı.</small>:null}{clericFeatures.blessedStrikes?<small>Blessed Strikes / Divine Strike progression aktif.</small>:null}{clericFeatures.divineIntervention?<small>Divine Intervention aktif.</small>:null}{clericFeatures.greaterDivineIntervention?<small>Greater Divine Intervention aktif.</small>:null}</div></section>:null}
          {isSorcerer&&sorcererFeatures.fontOfMagic?<section className="play-mode-card"><div className="play-mode-section-head"><div><span className="mini-label">Sorcerer</span><h2>Font of Magic</h2></div><strong>{sorceryPoints?`${sorceryPoints.max-sorceryPoints.used} / ${sorceryPoints.max} SP`:"Kaynak yok"}</strong></div><div className="play-mode-slot-grid">{spellSlots.filter(slot=>slot.level<=5).map(slot=>{const remaining=sorceryPoints?sorceryPoints.max-sorceryPoints.used:0;const cost=getSorcerySlotCost(slot.level)!;return <div className="play-mode-slot-row" key={slot.level}><div><span>Level {slot.level} Slot</span><small>{slot.max-slot.used}/{slot.max} hazır · Create {cost} SP · Convert +{slot.level} SP</small></div><div><button type="button" disabled={!sorceryPoints||!canCreateSorcerySlot(slot.level,remaining,slot.used>0)} onClick={()=>createSorcerySlot(slot.level)}>Slot Yarat</button><button type="button" disabled={!sorceryPoints||slot.used>=slot.max||remaining<=0} onClick={()=>convertSlotToSorceryPoints(slot.level)}>SP'ye Çevir</button></div></div>})}</div>{sorcererFeatures.sorcerousRestoration?<div className="condition-rule-summary"><small>Sorcerous Restoration aktif.</small></div>:null}</section>:null}
          {isWizard&&wizardFeatures.arcaneRecovery?<section className="play-mode-card"><div className="play-mode-section-head"><div><span className="mini-label">Wizard</span><h2>Arcane Recovery</h2></div><strong>{getArcaneRecoveryBudget(activeCharacter.level)-arcaneRecoveryLevels.reduce((sum,level)=>sum+level,0)} level bütçe</strong></div><div className="play-mode-slot-grid">{spellSlots.filter(slot=>slot.level<=5).map(slot=>{const selected=arcaneRecoveryLevels.filter(level=>level===slot.level).length;const remaining=getArcaneRecoveryBudget(activeCharacter.level)-arcaneRecoveryLevels.reduce((sum,level)=>sum+level,0);return <div className="play-mode-slot-row" key={slot.level}><div><span>Level {slot.level}</span><small>{slot.used} harcanmış · {selected} seçili</small></div><div><button type="button" disabled={!selected} onClick={()=>{const index=arcaneRecoveryLevels.indexOf(slot.level);setArcaneRecoveryLevels(current=>current.filter((_,i)=>i!==index))}}>−</button><button type="button" disabled={!arcaneRecovery||arcaneRecovery.used>=arcaneRecovery.max||!canRecoverWizardSlot(slot.level,slot.used-selected,remaining)} onClick={()=>setArcaneRecoveryLevels(current=>[...current,slot.level])}>+</button></div></div>})}</div><button type="button" disabled={!arcaneRecoveryLevels.length||!arcaneRecovery||arcaneRecovery.used>=arcaneRecovery.max} onClick={applyArcaneRecovery}>Seçili Slotları Yenile</button><div className="condition-rule-summary">{wizardFeatures.memorizeSpell?<small>Memorize Spell aktif.</small>:null}{wizardFeatures.spellMastery?<small>Spell Mastery aktif.</small>:null}{wizardFeatures.signatureSpells?<small>Signature Spells aktif.</small>:null}</div></section>:null}
          {isRanger?<section className="play-mode-card"><div className="play-mode-section-head"><div><span className="mini-label">Ranger Hunt</span><h2>Hunter's Mark · {getHuntersMarkDamage(activeCharacter.level,activeCharacter.ruleset)}</h2></div><strong>{favoredEnemy?`${favoredEnemy.max-favoredEnemy.used}/${favoredEnemy.max} ücretsiz`:activeCharacter.ruleset==="dnd_2014"?"Spell slot kullanır":"Kaynak yok"}</strong></div>{rangerFeatures.favoredEnemy?<button type="button" disabled={!favoredEnemy||favoredEnemy.used>=favoredEnemy.max||turnEconomy.bonusActionUsed} onClick={useFavoredEnemy}>Favored Enemy · Bonus Action</button>:null}<div className="condition-rule-summary">{rangerFeatures.deftExplorer?<small>Deft Explorer aktif.</small>:null}{rangerFeatures.extraAttack?<small>Extra Attack aktif.</small>:null}{rangerFeatures.roving?<small>Roving aktif.</small>:null}{rangerFeatures.tireless?<small>Tireless aktif.</small>:null}{rangerFeatures.naturesVeil?<small>Nature's Veil aktif.</small>:null}{rangerFeatures.foeSlayer?<small>Foe Slayer aktif.</small>:null}</div></section>:null}
          {featNames.some(name=>["alert","lucky","tough","mobile","observant"].includes(name.toLowerCase()))?<section className="play-mode-card"><div className="play-mode-section-head"><div><span className="mini-label">Feat Runtime</span><h2>Aktif Feat Etkileri</h2></div></div><div className="condition-rule-summary">{featRuntime.alertInitiativeBonus?<small>Alert: Initiative +{featRuntime.alertInitiativeBonus}</small>:null}{featRuntime.speedBonus?<small>Mobile: Speed +{featRuntime.speedBonus} ft.</small>:null}{featRuntime.toughHpBonus?<small>Tough: Max HP katkısı +{featRuntime.toughHpBonus}</small>:null}{featRuntime.passivePerceptionBonus?<small>Observant: Passive Perception/Investigation +5</small>:null}</div>{featRuntime.luckyUses?<button type="button" disabled={luckyUsed>=featRuntime.luckyUses} onClick={()=>setLuckyUsed(value=>value+1)}>Lucky Kullan · {featRuntime.luckyUses-luckyUsed}/{featRuntime.luckyUses}</button>:null}</section>:null}
          {magicAccessoryRuntime.activeItemNames.length?<section className="play-mode-card"><div className="play-mode-section-head"><div><span className="mini-label">Magic Accessories</span><h2>Attuned Passive Effects</h2></div><strong>{magicAccessoryRuntime.activeItemNames.length} aktif</strong></div><div className="condition-rule-summary"><small>{magicAccessoryRuntime.activeItemNames.join(" · ")}</small><small>Effective STR {effectiveCharacter.abilities.str} · CON {effectiveCharacter.abilities.con} · INT {effectiveCharacter.abilities.int}</small>{magicAccessoryRuntime.savingThrowBonus?<small>Saving Throws +{magicAccessoryRuntime.savingThrowBonus}</small>:null}{magicAccessoryRuntime.skillCheckBonus?<small>Ability Checks +{magicAccessoryRuntime.skillCheckBonus}</small>:null}{magicAccessoryRuntime.speedBonus?<small>Speed +{magicAccessoryRuntime.speedBonus} ft.</small>:null}</div></section>:null}
          {usableItems.length?<section className="play-mode-card"><div className="play-mode-section-head"><div><span className="mini-label">Inventory Runtime</span><h2>Consumables & Ammunition</h2></div><strong>{usableItems.reduce((sum,item)=>sum+item.entry.quantity,0)} adet</strong></div><div className="play-mode-slot-grid">{usableItems.map(({entry,item})=><div className="play-mode-slot-row" key={item.id}><div><span>{item.name}</span><small>{entry.quantity} adet · {getItemHealingFormula(item)??(getItemDamageProfile(item)?`${getItemDamageProfile(item)!.formula} ${getItemDamageProfile(item)!.damageType}`:item.category)}</small></div><button type="button" onClick={()=>consumeItem(item.id)}>{getItemDamageProfile(item)?"Fırlat":getItemHealingFormula(item)||getItemRestoration(item).curesConditions.length||getItemRestoration(item).clearsExhaustion?"Kullan":"1 Harca"}</button></div>)}</div></section>:null}
          {magicItems.length?<section className="play-mode-card"><div className="play-mode-section-head"><div><span className="mini-label">Magic Items</span><h2>Attunement & Charges</h2></div><strong>{getAttunedItemCount(activeCharacter.inventory)} / 3 attuned</strong></div><div className="play-mode-slot-grid">{magicItems.map(({entry,item})=><div className="play-mode-slot-row" key={item.id}><div><span>{item.name} · {item.rarity}</span><small>{item.charges?`${item.charges-(entry.chargesUsed??0)} / ${item.charges} charge`:item.requiresAttunement?(entry.attuned?"Attuned":"Attunement gerekli"):"Attunement gerektirmez"}</small></div><div>{item.requiresAttunement?<button type="button" onClick={()=>toggleAttunement(item.id)}>{entry.attuned?"Bağı Kes":"Attune"}</button>:null}{item.charges?<button type="button" disabled={(entry.chargesUsed??0)>=item.charges||Boolean(item.requiresAttunement&&!entry.attuned)} onClick={()=>spendMagicItemCharge(item.id)}>1 Charge</button>:null}</div></div>)}</div></section>:null}
          <section className="play-mode-card play-mode-hp-card">
            <div className="play-mode-section-head">
              <div><span className="mini-label">Hit Points</span><h2>Can Yönetimi</h2></div>
              <strong className="play-mode-hp-number">{activeCharacter.currentHp} / {activeCharacter.maxHp}</strong>
            </div>

            <div className="play-mode-hp-bar"><span style={{ width: `${hpPercent}%` }} /></div>

            <div className="play-mode-big-buttons">
              {[-10, -5, -1, 1, 5, 10].map((amount) => (
                <button key={amount} onClick={() => updateHp(amount)}>
                  {amount > 0 ? `+${amount}` : amount}
                </button>
              ))}
            </div>

            <div className="survival-console">
              <input type="number" min="1" value={survivalAmount} onChange={event=>setSurvivalAmount(Math.max(1,Number(event.target.value)||1))}/>
              <select aria-label="Gelen hasar türü" value={incomingDamageType} onChange={event=>setIncomingDamageType(event.target.value)}><option value="physical">Physical</option><option value="fire">Fire</option><option value="cold">Cold</option><option value="lightning">Lightning</option><option value="poison">Poison</option><option value="acid">Acid</option><option value="necrotic">Necrotic</option><option value="radiant">Radiant</option><option value="psychic">Psychic</option><option value="force">Force</option><option value="thunder">Thunder</option></select>
              <button type="button" onClick={()=>takeDamage(false)}>Hasar Al</button>
              <button type="button" onClick={()=>takeDamage(true)}>Kritik Hasar</button>
              <button type="button" onClick={healDamage}>İyileştir</button>
            </div>
            {isBarbarian?<label className="rage-resistance-toggle"><input type="checkbox" checked={incomingPhysical} onChange={event=>setIncomingPhysical(event.target.checked)}/> Gelen hasar fiziksel</label>:null}
            {itemEffectRuntime.damageResistance?<label className="rage-resistance-toggle"><input type="checkbox" checked={incomingPotionResisted} onChange={event=>setIncomingPotionResisted(event.target.checked)}/> Gelen hasar potion direnciyle eşleşiyor</label>:null}
            {magicArmorRuntime.resistanceDamageTypes.length?<small>Armor Resistance: {magicArmorRuntime.resistanceDamageTypes.join(", ")}</small>:null}
            {magicArmorRuntime.preventsCriticalDamage?<small>Adamantine: gelen critical hit normal hit sayılır.</small>:null}
            {pendingConcentrationDc?<button type="button" className="concentration-prompt" onClick={()=>concentrationSave(pendingConcentrationDc)}>Concentration Save At · DC {pendingConcentrationDc}</button>:null}
            {activeCharacter.currentHp===0?<div className="death-save-console"><strong>Death Saves · ✓ {activeCharacter.deathSaves.successes}/3 · ✕ {activeCharacter.deathSaves.failures}/3</strong><button type="button" disabled={activeCharacter.deathSaves.successes>=3||activeCharacter.deathSaves.failures>=3} onClick={rollDeathSave}>Death Save At</button></div>:null}

            <label className="play-mode-temp-hp">
              Temp HP
              <input
                type="number"
                min="0"
                value={activeCharacter.tempHp}
                onChange={(event) => commit({ tempHp: Math.max(0, Number(event.target.value)) })}
              />
            </label>
          </section>

          {pactMagicSlots.length?<section className="play-mode-card"><div className="play-mode-section-head"><div><span className="mini-label">Multiclass Warlock</span><h2>Pact Magic Slots</h2></div><button onClick={()=>commit({pactMagicSlots:resetSpellSlots(pactMagicSlots)})}>Short Rest Yenile</button></div><div className="play-mode-slot-grid">{pactMagicSlots.map(slot=><div className="play-mode-slot-row" key={slot.level}><div><span>Level {slot.level} Pact Slot</span><strong>{slot.max-slot.used}/{slot.max}</strong></div><div><button disabled={slot.used>=slot.max} onClick={()=>commit({pactMagicSlots:pactMagicSlots.map(item=>item.level===slot.level?{...item,used:item.used+1}:item)})}>−</button><button disabled={slot.used<=0} onClick={()=>commit({pactMagicSlots:pactMagicSlots.map(item=>item.level===slot.level?{...item,used:item.used-1}:item)})}>+</button></div></div>)}</div></section>:null}
          <section className="play-mode-card">
            <div className="play-mode-section-head">
              <div><span className="mini-label">Conditions</span><h2>Durumlar</h2></div>
              <span>{activeCharacter.conditions.length} aktif</span>
            </div>

            <div className="play-mode-condition-grid">
              {conditionOptions.map((condition) => (
                <button
                  className={activeCharacter.conditions.includes(condition) ? "active" : ""}
                  key={condition}
                  onClick={() => toggleCondition(condition)}
                >
                  {condition}
                </button>
              ))}
            </div>
            {conditionEffects.notes.length?<div className="condition-rule-summary">{conditionEffects.notes.map(note=><small key={note}>{note}</small>)}</div>:null}
            <div className="exhaustion-console"><div><span className="mini-label">Exhaustion</span><strong>{exhaustionEffects.level} / 6</strong><small>{activeCharacter.ruleset==="dnd_2024"?`D20 -${exhaustionEffects.d20Penalty} · Speed ${effectiveSpeed} ft.`:`Speed ${effectiveSpeed} ft. · Effective Max HP ${effectiveMaxHp}`}</small>{exhaustionEffects.dead?<em>Level 6 · Ölü</em>:null}</div><div><button type="button" disabled={exhaustionEffects.level<=0} onClick={()=>commit({exhaustion:exhaustionEffects.level-1})}>−</button><button type="button" disabled={exhaustionEffects.level>=6} onClick={()=>commit({exhaustion:exhaustionEffects.level+1})}>+</button></div></div>
          </section>

          {metamagicOptions.length ? (
            <section className="play-mode-card">
              <div className="play-mode-section-head">
                <div><span className="mini-label">Sorcerer</span><h2>Metamagic</h2></div>
                <strong>{sorceryPoints ? `${sorceryPoints.max - sorceryPoints.used} / ${sorceryPoints.max} SP` : "SP yok"}</strong>
              </div>

              <div className="play-mode-slot-grid">
                {metamagicOptions.map((option) => (
                  <div className="play-mode-slot-row" key={option.id}>
                    <div><span>{option.name}</span><small>{option.summary}</small></div>
                    <button
                      type="button"
                      disabled={!sorceryPoints || sorceryPoints.max - sorceryPoints.used < option.cost}
                      onClick={() => spendSorceryPoints(option.cost)}
                    >
                      Kullan · {option.cost} SP
                    </button>
                  </div>
                ))}
              </div>
            </section>
          ) : null}

          {invocations.length ? (
            <section className="play-mode-card">
              <div className="play-mode-section-head">
                <div><span className="mini-label">Warlock</span><h2>Eldritch Invocations</h2></div>
                <strong>{invocations.length} aktif</strong>
              </div>
              <div className="play-mode-slot-grid">
                {invocations.map((option) => <div className="play-mode-slot-row" key={option.id}><div><span>{option.name}</span><small>{option.summary}</small></div></div>)}
              </div>
            </section>
          ) : null}

          {wildShapeForms.length ? <section className="play-mode-card"><div className="play-mode-section-head"><div><span className="mini-label">Druid</span><h2>Wild Shape</h2></div><strong>{wildShapeResource?`${wildShapeResource.max-wildShapeResource.used} / ${wildShapeResource.max} kullanım`:"Kaynak yok"}</strong></div><div className="play-mode-slot-grid">{wildShapeForms.map(form=><div className="play-mode-slot-row" key={form.id}><div><span>{form.name} · CR {form.challengeRating}</span><small>AC {form.armorClass} · HP {form.hitPoints} · {form.movement}</small></div><button type="button" disabled={!wildShapeResource||wildShapeResource.used>=wildShapeResource.max} onClick={useWildShape}>Dönüş</button></div>)}</div></section>:null}

          {maneuvers.length?<section className="play-mode-card"><div className="play-mode-section-head"><div><span className="mini-label">Battle Master · {getSuperiorityDie(activeCharacter.level)}</span><h2>Maneuvers</h2></div><strong>{superiorityDice?`${superiorityDice.max-superiorityDice.used} / ${superiorityDice.max} zar`:"Kaynak yok"}</strong></div><div className="play-mode-slot-grid">{maneuvers.map(option=><div className="play-mode-slot-row" key={option.id}><div><span>{option.name}</span><small>{option.trigger} · {option.summary}</small></div><button type="button" disabled={!superiorityDice||superiorityDice.used>=superiorityDice.max} onClick={useSuperiorityDie}>Zar Harca</button></div>)}</div></section>:null}

          {companion&&companionStats?<section className="play-mode-card"><div className="play-mode-section-head"><div><span className="mini-label">Beast Master Companion</span><h2>{companion.name}</h2></div><strong>{companionCurrentHp} / {companionStats.maxHp} HP</strong></div><p>{companion.summary}</p><div className="play-mode-core-stats"><div><span>AC</span><strong>{companionStats.armorClass}</strong></div><div><span>Attack</span><strong>{formatModifier(companionStats.attackBonus)}</strong></div><div><span>Damage</span><strong>{companionStats.damage}</strong></div></div><div className="play-mode-big-buttons">{[-5,-1,1,5].map(amount=><button key={amount} onClick={()=>updateCompanionHp(amount)}>{amount>0?`+${amount}`:amount}</button>)}</div><small>{companion.attackName} · {companion.speed}</small></section>:null}

          {classActions.length?<section className="play-mode-card"><div className="play-mode-section-head"><div><span className="mini-label">Core Class Actions</span><h2>{activeCharacter.className} Kaynakları</h2></div></div><div className="play-mode-slot-grid">{classActions.map(action=>{const resourceId=action.resourceId!;const resource=activeCharacter.resources.find(item=>item.id===resourceId)!;const remaining=resource.unlimited?Number.POSITIVE_INFINITY:resource.max-resource.used;return <div className="play-mode-slot-row" key={action.id}><div><span>{action.name} · {action.actionType}</span><small>{action.summary}</small><strong>{resource.unlimited?"∞ kullanım":`${remaining} / ${resource.max} kaldı`} · {resource.shortRecoveryAmount?`Short Rest +${resource.shortRecoveryAmount}`:`${resource.recovery} rest`}</strong></div>{resourceId==="lay-on-hands"?<div>{[1,5,10].map(amount=><button key={amount} disabled={remaining<amount} onClick={()=>executeClassAction(resourceId,amount)}>+{amount} HP</button>)}</div>:<button type="button" disabled={remaining<1} onClick={()=>executeClassAction(resourceId)}>{resourceId==="second-wind"?"İyileş":"Kullan"}</button>}</div>})}</div></section>:null}

          {arcanumSpells.length?<section className="play-mode-card"><div className="play-mode-section-head"><div><span className="mini-label">Warlock · Long Rest</span><h2>Mystic Arcanum</h2></div><strong>{arcanumSpells.length-(activeCharacter.usedArcanumSpellIds??[]).length} hazır</strong></div><div className="play-mode-spell-list">{arcanumSpells.sort((a,b)=>a.level-b.level).map(spell=>{const used=activeCharacter.usedArcanumSpellIds?.includes(spell.id);return <button key={spell.id} disabled={used} onClick={()=>castArcanum(spell.id)}><span>Level {spell.level} · {spell.name}</span><small>{used?"Kullanıldı":"Arcanum Kullan"}</small></button>})}</div></section>:null}

          {isPaladin(activeCharacter.className)&&activeCharacter.level>=2?<section className="play-mode-card"><div className="play-mode-section-head"><div><span className="mini-label">Paladin Combat</span><h2>Divine Smite</h2></div><label><input type="checkbox" checked={smiteHolyTarget} onChange={event=>setSmiteHolyTarget(event.target.checked)}/> Fiend / Undead</label></div><div className="play-mode-slot-grid">{spellSlots.map(slot=>{const dice=getDivineSmiteDice(slot.level,activeCharacter.ruleset,smiteHolyTarget);return <div className="play-mode-slot-row" key={slot.level}><div><span>Level {slot.level} Slot · {dice}d8 radiant</span><small>{slot.max-slot.used} / {slot.max} slot kaldı</small></div><button type="button" disabled={slot.used>=slot.max} onClick={()=>divineSmite(slot.level)}>Smite At</button></div>})}</div>{paladinAuras?<div className="play-mode-slot-grid">{paladinAuras.protection?<div className="play-mode-slot-row"><div><span>Aura of Protection · {paladinAuras.protection.radius} ft.</span><small>{paladinAuras.protection.summary}</small></div></div>:null}{paladinAuras.courage?<div className="play-mode-slot-row"><div><span>Aura of Courage · {paladinAuras.courage.radius} ft.</span><small>{paladinAuras.courage.summary}</small></div></div>:null}{paladinAuras.radiantStrikes?<div className="play-mode-slot-row"><div><span>Radiant Strikes</span><small>{paladinAuras.radiantStrikes}</small></div></div>:null}</div>:null}</section>:null}

          {activeSpellEffects.length?<section className="play-mode-card"><div className="play-mode-section-head"><div><span className="mini-label">Persistent Magic</span><h2>Aktif Spell Etkileri</h2></div><button type="button" onClick={advanceEffectRound}>1 Round İlerle</button></div><div className="play-mode-slot-grid">{activeSpellEffects.map(effect=><div className="play-mode-slot-row" key={effect.id}><div><span>{effect.name}{effect.concentration?" · Concentration":""}</span><small>{effect.remainingRounds===null?"Süresiz":`${effect.remainingRounds} round kaldı`} · {effect.conditions?.length?`${effect.conditions.join(", ")} · `:""}{effect.summary}</small></div><button type="button" onClick={()=>endSpellEffect(effect.id)}>Bitir</button></div>)}</div>{activeSpellEffects.some(effect=>effect.concentration)?<div className="play-mode-big-buttons"><span>Concentration save:</span>{[10,15,20].map(dc=><button type="button" key={dc} onClick={()=>concentrationSave(dc)}>DC {dc}</button>)}</div>:null}</section>:null}

          <section className="play-mode-card">
            <div className="play-mode-section-head">
              <div><span className="mini-label">Spell Slots</span><h2>Kaynaklar</h2></div>
              <button onClick={() => commit({ spellSlots: resetSpellSlots(spellSlots) })}>Slotları Yenile</button>
            </div>

            <div className="play-mode-slot-grid">
              {spellSlots.length === 0 ? (
                <p>Spell slot yok. Bazen sorun büyü değil, sınıf seçimidir.</p>
              ) : spellSlots.map((slot) => (
                <div className="play-mode-slot-row" key={slot.level}>
                  <div><span>Level {slot.level}</span><strong>{slot.max - slot.used} / {slot.max}</strong></div>
                  <div>
                    <button onClick={() => spendSlot(slot.level, 1)} disabled={slot.used >= slot.max}>−</button>
                    <button onClick={() => spendSlot(slot.level, -1)} disabled={slot.used <= 0}>+</button>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section className="play-mode-card">
            <div className="play-mode-section-head">
              <div><span className="mini-label">Quick Rolls</span><h2>Hızlı Zarlar</h2></div>
            </div>

            <div className="play-mode-roll-grid">
              {(Object.keys(abilityLabels) as AbilityKey[]).map((ability) => (
                <button
                  key={ability}
                  onClick={() => quickRoll(
                    abilityLabels[ability],
                    getAbilityModifier(effectiveCharacter.abilities[ability])+magicAccessoryRuntime.skillCheckBonus,
                  )}
                >
                  {abilityLabels[ability]}
                  <span>{formatModifier(getAbilityModifier(effectiveCharacter.abilities[ability])+magicAccessoryRuntime.skillCheckBonus)}</span>
                </button>
              ))}
            </div>

            <div className="attack-control-bar">
              <label><input type="checkbox" checked={offhandAttack} onChange={event=>setOffhandAttack(event.target.checked)}/> Off-hand attack</label>
              <label>Hedef AC<input type="number" min="1" value={targetAc} onChange={event=>setTargetAc(Math.max(1,Number(event.target.value)||1))}/></label>
              <label>Atış<select value={attackMode} onChange={event=>setAttackMode(event.target.value as RollMode)}><option value="normal">Normal</option><option value="advantage">Advantage</option><option value="disadvantage">Disadvantage</option></select></label>
              <label>Hedef türü<select value={magicWeaponTarget} onChange={event=>setMagicWeaponTarget(event.target.value as MagicWeaponTarget)}><option value="normal">Normal</option><option value="dragon">Dragon</option><option value="giant">Giant</option><option value="undead-fiend">Undead / Fiend</option></select></label>
              {masteryVexReady?<strong>Vex Advantage hazır</strong>:null}
            </div>

            {equippedItems.weapons.map((weapon) => (
              <button
                className="play-mode-weapon-roll"
                key={weapon.id}
                disabled={conditionEffects.blocksActions||exhaustionEffects.dead||turnEconomy.actionUsed||itemEffectRuntime.blocksAggressiveActions}
                onClick={() => weaponAttack(weapon)}
              >
                <span>{weapon.name}</span>
                <strong>{formatModifier(getWeaponAttackBonus(effectiveCharacter, weapon))}</strong>
                <small>{getWeaponDamageSummary(effectiveCharacter, weapon)}</small>
              </button>
            ))}

            <div className="play-mode-roll-history">
              {rollHistory.length === 0 ? <p>Henüz zar atılmadı.</p> : rollHistory.map((roll) => (
                <div key={roll.id}><span>{roll.label}<small>{roll.notation}</small></span><strong>{roll.total}</strong></div>
              ))}
            </div>
          </section>

          <section className="play-mode-card">
            <div className="play-mode-section-head"><div><span className="mini-label">Checks & Saves</span><h2>Skill ve Saving Throws</h2></div><select value={checkMode} onChange={event=>setCheckMode(event.target.value as RollMode)}><option value="normal">Normal</option><option value="advantage">Advantage</option><option value="disadvantage">Disadvantage</option></select></div>
            <div className="save-roll-grid">{(Object.keys(abilityLabels) as AbilityKey[]).map(ability=>{const bonus=getSavingThrowBonus(effectiveCharacter,ability,rulesetData)+magicAccessoryRuntime.savingThrowBonus;return <button type="button" disabled={exhaustionEffects.dead} key={ability} onClick={()=>resolvedCheck(`${abilityLabels[ability]} Saving Throw`,bonus,"save",ability)}><span>{abilityLabels[ability]} Save</span><strong>{formatModifier(bonus-exhaustionEffects.d20Penalty)}</strong></button>})}</div>
            <div className="skill-roll-grid">{Object.keys(SKILL_ABILITIES).map(skill=>{const bonus=getSkillBonus(effectiveCharacter,skill)+magicAccessoryRuntime.skillCheckBonus;const expertise=activeCharacter.expertiseSkills.includes(skill);const proficient=activeCharacter.skillProficiencies.includes(skill);return <button type="button" disabled={exhaustionEffects.dead} key={skill} onClick={()=>resolvedCheck(`${skill} Check`,bonus,"skill")}><span>{skill}<small>{expertise?"Expertise":proficient?"Proficient":activeCharacter.className.toLowerCase()==="bard"&&activeCharacter.level>=2?"Jack of All Trades":"Untrained"}</small></span><strong>{formatModifier(bonus-exhaustionEffects.d20Penalty)}</strong></button>})}</div>
          </section>

          <section className="play-mode-card play-mode-spell-card">
            <div className="play-mode-section-head">
              <div><span className="mini-label">Prepared Spells</span><h2>Hızlı Büyüler</h2></div>
              <span>{spells.length} hazır</span>
            </div>

            <div className="spell-target-console"><label>Hedef modu<select value={spellTargetMode} onChange={event=>setSpellTargetMode(event.target.value as RollMode)}><option value="normal">Normal</option><option value="advantage">Advantage</option><option value="disadvantage">Disadvantage</option></select></label><label>Hedef save bonus<input type="number" value={targetSaveBonus} onChange={event=>setTargetSaveBonus(Number(event.target.value)||0)}/></label><label>Başarılı save<select value={saveDamageRule} onChange={event=>setSaveDamageRule(event.target.value as "auto"|SaveDamageRule)}><option value="auto">Büyü kuralı</option><option value="half">Yarım hasar</option><option value="none">Hasar yok</option></select></label><small>Spell attack büyüleri Quick Rolls bölümündeki hedef AC değerini kullanır.</small></div>

            <label className="rage-resistance-toggle">Etki alanındaki hedef sayısı<input type="number" min="1" max="20" value={spellTargetCount} onChange={event=>setSpellTargetCount(Math.max(1,Math.min(20,Number(event.target.value)||1)))}/></label>
            <div className="play-mode-spell-list">
              {spellGroups.length === 0 ? <p>Hazır büyü bulunamadı.</p> : spellGroups.map((group) => (
                <div key={group.level} className="play-mode-spell-group">
                  <strong>{group.level === 0 ? "Cantrips" : `Level ${group.level}`}</strong>
                  {group.spells.map((spell) => {
                    const castableLevels=getCastableSlotLevels(spell,spellSlots);const selectedSlot=castSlotLevels[spell.id]&&castableLevels.includes(castSlotLevels[spell.id])?castSlotLevels[spell.id]:castableLevels[0];
                    const disabled = spell.level > 0 && !selectedSlot;const formula=getSpellRollFormula(spell,activeCharacter.level,selectedSlot??spell.level);const behavior=getSpellBehavior(spell,selectedSlot??spell.level);const material=getSpellMaterialReadiness(spell,activeCharacter.inventory,rulesetData?.items??[]);const sourceStats=getSpellcastingStatsForSpell(effectiveCharacter,spell,rulesetData);const rowAbility=sourceStats?.spellcastingAbility??spellcastingAbility;
                    return (
                      <div className="play-mode-slot-row" key={spell.id}><div><span>{spell.name}{spell.concentration ? " · C" : ""}{sourceStats ? ` · ${sourceStats.className} (${sourceStats.spellcastingAbility.toUpperCase()})` : ""}</span><small>{[formula,spell.attackType==="saving-throw"&&spell.saveAbility?`${spell.saveAbility.toUpperCase()} save DC ${getSpellSaveDc(effectiveCharacter,rowAbility)}`:spell.attackType==="spell-attack"?`Spell attack ${formatModifier(getSpellAttackBonus(effectiveCharacter,rowAbility))}`:null,behavior.area?`AoE ${behavior.area}`:null,behavior.targetCount>1?`${behavior.targetCount} hedef`:null,behavior.repeatSave?"Repeat save":null,behavior.summoning?"Summon":null,behavior.movement?"Movement":null,material.message??behavior.materialWarning].filter(Boolean).join(" · ")||"Utility"}</small></div>{spell.level>0?<select aria-label={`${spell.name} slot level`} disabled={!castableLevels.length} value={selectedSlot??""} onChange={event=>setCastSlotLevels(current=>({...current,[spell.id]:Number(event.target.value)}))}>{castableLevels.map(level=><option key={level} value={level}>L{level} slot</option>)}</select>:null}<button disabled={disabled} onClick={()=>castSpell(spell.id,selectedSlot)}>{spell.level===0?"Cantrip":disabled?"Slot yok":"Cast"}</button>{behavior.ritual?<button type="button" disabled={turnEconomy.actionUsed} onClick={()=>castSpell(spell.id,spell.level,false)}>Ritual</button>:null}</div>
                    );
                  })}
                </div>
              ))}
            </div>
          </section>

          {(homebrewContentRuntime.feats.length||homebrewContentRuntime.spells.length||homebrewContentRuntime.items.length) ? <section className="play-mode-card">
            <div className="play-mode-section-head"><div><span className="mini-label">Homebrew Content Runtime</span><h2>Feat, Spell & Item</h2></div><strong>{homebrewContentRuntime.ready?"Ready":"Needs attention"}</strong></div>
            {homebrewContentRuntime.blockers.length?<div className="condition-rule-summary">{homebrewContentRuntime.blockers.map(message=><small key={message}>Blocker: {message}</small>)}</div>:null}
            {homebrewContentRuntime.feats.length?<div className="play-mode-roll-history">{homebrewContentRuntime.feats.map(entry=><div key={entry.entityId}><span>{entry.feat.name}<small>{entry.passiveSummaries.join(" · ")}</small></span><strong>{entry.choiceComplete?"Aktif":"Seçim eksik"}</strong></div>)}</div>:null}
            {homebrewContentRuntime.spells.length?<div className="play-mode-roll-history">{homebrewContentRuntime.spells.map(entry=><div key={entry.entityId}><span>{entry.spell.name}<small>{[entry.formula,entry.spell.effectType,entry.prepared?"Prepared":entry.known?"Known":null,...entry.warnings].filter(Boolean).join(" · ")}</small></span><strong>{entry.automatic?"Automatic":"Guided"}</strong></div>)}</div>:null}
            {homebrewContentRuntime.items.length?<div className="play-mode-roll-history">{homebrewContentRuntime.items.map(entry=><div key={entry.entityId}><span>{entry.item.name}<small>{[...entry.effectSummary,entry.chargesRemaining!==undefined?`${entry.chargesRemaining} charge`:null,entry.item.requiresAttunement?(entry.attuned?"Attuned":"Attunement gerekli"):null].filter(Boolean).join(" · ")}</small></span><strong>{entry.usable?"Kullanılabilir":"Hazır değil"}</strong></div>)}</div>:null}
          </section>:null}

          {homebrewRuntime.entities.length ? <section className="play-mode-card">
            <div className="play-mode-section-head"><div><span className="mini-label">Homebrew Runtime</span><h2>Özel Özellikler</h2></div>{homebrewRuntime.needsResourceSync?<button type="button" onClick={syncHomebrewResources}>Kaynakları Senkronize Et</button>:null}</div>
            {homebrewRuntime.progressionFeatures.length?<div className="play-mode-roll-history">{homebrewRuntime.progressionFeatures.map(feature=><div key={`${feature.entityId}-${feature.level}-${feature.name}`}><span>{feature.name}<small>{feature.entityName} · Level {feature.level}</small></span><strong>Aktif</strong></div>)}</div>:null}
            <div className="play-mode-class-actions">{homebrewRuntime.actions.filter(item=>item.action.economy!=="passive").map(item=><button type="button" key={item.id} disabled={!item.available} onClick={()=>executeHomebrewAction(item.id)}><span>{item.action.name}</span><small>{item.entityName} · {item.action.economy}{item.resourceId?` · ${item.action.resourceCost??0} kaynak`:""}</small>{item.reason?<small>{item.reason}</small>:null}</button>)}</div>
          </section>:null}

          <section className="play-mode-card play-mode-rest-card">
            <div className="play-mode-section-head">
              <div><span className="mini-label">Rest</span><h2>Dinlenme</h2></div>
            </div>

            <div className="play-mode-rest-actions">
              {hitDice.map((pool) => (
                <button key={pool.die} disabled={pool.used >= pool.max} onClick={() => shortRest(pool.die)}>
                  Short Rest d{pool.die}
                  <small>{pool.max - pool.used} / {pool.max} kaldı</small>
                </button>
              ))}
              <button className="primary-action" onClick={longRest}>Long Rest</button>
            </div>
          </section>
        </div>
      </div>
    </PageShell>
  );
}

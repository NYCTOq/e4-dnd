# v5.38.0 — Ranger Race, Subclass & Level Certification

- 760 Ranger race/species × subclass × level senaryosu.
- 2014 known-spell ve 2024 prepared-spell progression ayrımı.
- Favored Enemy, Hunter’s Mark, Weapon Mastery, Expertise ve Ranger core checkpoint düzeltmeleri.
- Hunter ve Beast Master level 3/7/11/15 sertifikası.
- 2014 companion proficiency scaling ve 2024 primal companion doğrulaması.

# v5.37.0 — Paladin Race, Oath & Level Certification

- 760 Paladin race/species × oath × level senaryosu.
- 2014/2024 Lay on Hands, Smite, Channel Divinity, prepared spells, aura ve touch ayrımları.
- Oath of Devotion ve Oath of the Ancients checkpoint sertifikası.

# v5.36.0 — Monk Race, Subclass & Level Certification

- 760 Monk race/species × subclass × level senaryosu
- 2014 Ki ve 2024 Focus progression ayrımı
- Martial Arts, Unarmored Movement ve Heightened Focus tabloları doğrulandı
- Open Hand ve Shadow checkpointleri edition-aware hale getirildi
- Perfect Self, Perfect Focus ve Body and Mind capstone ayrımı kapatıldı

# v5.35.0 — Fighter Race, Subclass & Level Certification

- 760 Fighter race/species × subclass × level senaryosu
- 2024 Second Wind ve Weapon Mastery tabloları düzeltildi
- Tactical Mind/Shift/Master ve Studied Attacks edition-aware oldu
- Champion 2014/2024 checkpointleri ayrıldı
- Battle Master level 10 ve 18 progression boşlukları kapatıldı
- Fighter kaynak, rest ve Play Mode bağlantıları düzeltildi

# v5.31.0 — Barbarian Race, Subclass & Level Certification

- 760 Barbarian race/species × subclass × level senaryosu
- 2014 ve 2024 resmi progression tabloları
- Rage use/recovery edition ayrımı
- Brutal Critical ve Brutal Strike ayrımı
- 2014 unlimited Rage, 2024 partial Short Rest recovery
- Berserker/Totem/World Tree feature checkpoint kapanışı

# v5.8.0 — UI, Mobile & Accessibility Polish Mega Pack

- Reusable dialog focus trap, Escape close and opener restoration
- Release Notes and Storage Recovery dialogs connected to focus management
- 44 px touch target, safe-area and compact mobile layout guards
- Horizontal overflow and responsive media safeguards
- Reduced-motion and validation focus polish
- UI/mobile/accessibility certification audit and tests
- 127 test files / 444 tests passing; production and PWA build passing

# v5.5.0 — Level Up, Feat & Choice Completion Mega Pack

- ASI ve feat kilometre taşları aynı Level Up akışında doğrulanır.
- Ability seçimi isteyen featler alt seçim tamamlanmadan uygulanamaz.
- Feat alt seçimleri karakter verisinde kalıcı saklanır ve ability artışı 20 sınırıyla uygulanır.
- Subclass, Fighting Style, Weapon Mastery, Metamagic, Invocation, Wild Shape, Maneuver, Companion, Expertise ve Mystic Arcanum borçları ortak completion raporunda izlenir.
- Eksik seçenek kataloğu blocker, çözülebilir seçim borcu görünür takip maddesi olur.

# v5.4.0 — Class & Subclass Runtime Closure Mega Pack

- Class progression feature'larını action, bonus action, reaction, resource, recovery, passive ve progression mekaniklerine göre sertifikalar.
- 12 ana class için dedicated runtime engine ve level 20 capstone bağlantısını denetler.
- Subclass feature'larını gerçek Play Mode action/resource veya pasif modifier bağlantısına göre automatic, guided, table-ruling ve blocked olarak ayırır.
- Eksik feature adı/özeti, geçersiz selection level, boş progression ve eksik class engine durumlarını release blocker yapar.
- Class ve subclass bazlı skor, blocker, warning ve release dostu özet üretir.

# v5.3.0 — Spell Certification Expansion Mega Pack

- Spell catalog is certified by mechanical families instead of name-only coverage.
- Damage, healing, concentration/control, summoning, movement, reaction, restoration, resurrection, material-cost and utility families are reported separately.
- Every spell receives automatic, guided, table-ruling or blocked disposition.
- Missing damage resolution, reaction trigger, resurrection cost and critical spell metadata become explicit blockers.
- Guided summon, restoration, resurrection and reaction instructions remain visible for player/DM resolution.
- Family-level readiness, score, blocker and warning summaries support release audits.

# v5.2.0 — Runtime Coverage Closure Mega Pack

- Added a central runtime closure report for classes, subclasses, feats, spells and items.
- Missing runtime behavior now produces explicit release blockers.
- Assisted behavior remains visible with a guided Play Mode action policy.
- Manual behavior is retained only with an explicit table-ruling explanation.
- Added per-entity closure lookup and release-friendly summary output.
- Added six runtime closure certification tests.

# v5.1.0 — Stable Player Post-Release QA & Bug Closure Mega Pack

- 2014/2024 martial and caster journeys, multiclass, level 1–20, spell/rest, equipment, backup, offline/mobile and keyboard flows are represented in one QA matrix.
- Missing scenario evidence is visible as a warning instead of being silently treated as passed.
- Critical player journey failures block release readiness.
- Duplicate evidence keeps the worst result so a later pass cannot hide an earlier unresolved regression.
- Non-critical visual regressions remain review notes without masking gameplay blockers.

# v5.0.0 — Stable Player Release

- E4 D&D player journey is promoted to the stable release channel.
- A single stable manifest now combines hardening, runtime coverage, player journey, data integrity, localization, accessibility and licensing gates.
- Version mismatch, missing runtime behavior, failed migration, unresolved crash, invalid backup or failed test/build/browser gates block the release.
- The manifest exposes stable status, readiness score, blockers, warnings and explicit player guarantees.

# v4.12.0 — Stable Player Release Hardening Mega Pack

- Unit/integration, production build and browser E2E release gates were unified.
- Current and legacy full backups are parsed, hydrated and certified before restore.
- Detached rollback backups protect restore workflows from accidental shared mutation.
- Migration failures and unresolved crash records are hard release blockers.
- Recovery quarantine records are visible release warnings instead of silent data loss.

# v4.9.0 — Equipment & Magic Item Closure Mega Pack

- Starting equipment ve pack içeriklerini duplicate üretmeden envantere ekleyen ortak runtime
- Weapon property kombinasyonlarının normalize edilmesi
- Attunement sınırı ve uygunluk raporu
- Charge kullanımı, kalan kullanım ve item spell casting planı
- Curse etiketi, item save DC ve attack bonus fallback desteği
- Encumbrance, ağırlık, kapasite ve kalan taşıma alanının tek özette birleştirilmesi
- Yeni equipment closure sertifikasyon testleri

# v4.8.0 — Player Journey Consistency Mega Pack

- Builder, Editor, Detail, Character Sheet ve Play Mode için merkezi karakter snapshot motoru.
- AC, initiative, speed, passive Perception, skill/save, spell DC/attack ve attacks-per-action ortak hesap kaynağı.
- Ruleset verisinden spellcasting ability çözümü.
- Resource remaining/recovery görünümü ve snapshot tutarlılık denetimi.
- Mevcut armor helper fonksiyonları merkezi hesap katmanına bağlandı.

# v4.7.0 — Unified Character Choices Mega Pack

- Builder, Level Up, Character Editor ve Choice Debt Resolver için ortak seçim modeli eklendi.
- Subclass, Fighting Style, Weapon Mastery, Metamagic, Invocation, Wild Shape, Maneuver, Companion, Expertise ve Mystic Arcanum tek runtime kataloğunda birleştirildi.
- Seçim limitleri, prerequisite filtreleri, geçerli seçim sayısı ve eksik seçim borcu aynı kaynaktan hesaplanıyor.
- Tekli, çoklu ve spell-level gruplu seçimler için ortak uygulama motoru eklendi.
- Choice Debt Resolver tekrar eden class-specific seçenek kodlarından arındırıldı.
- Yeni unified choice sertifikasyon testleri eklendi.

# v4.6.0 — Full Character Certification Mega Pack

- 12 class × 2 edition için 24 kombinasyonluk sertifikasyon matrisi eklendi.
- Her class için kritik level, subclass unlock, spell progression ve level 20 capstone doğrulaması eklendi.
- Level 1–20 içerik/referans sertifikası ile runtime coverage tek üst raporda birleştirildi.
- Character integrity ve create → level up → rest → backup restore lifecycle sertifika yardımcıları eklendi.
- Gerçek 2014/2024 veri paketleriyle entegrasyon matrisi ve regresyon testleri eklendi.

## v4.5.0 — Global Spell Runtime Mega Pack (17 Temmuz 2026)

- Damage, healing, spell attack ve saving throw çözümünü ortak global runtime altında birleştirdi.
- Slot/cantrip scaling, upcast hedef artışı ve normal + Pact Magic slot seçeneklerini ortaklaştırdı.
- Full/half/zero save sonuçları, healing cap ve overheal raporu eklendi.
- Concentration değiştirme/bitirme, repeat-save, condition effect ve süre takibi güçlendirildi.
- AoE, summon, movement, reaction, ritual ve material gereksinimleri için tek davranış planı eklendi.
- Dispel/effect temizleme yardımcıları ve global spell runtime sertifikasyon testleri eklendi.

## v4.4.0 — Arcane Classes Mega Pack (17 Temmuz 2026)

- Bard, Sorcerer, Warlock ve Wizard için 2014/2024 ortak arcane runtime matrisi.
- Bardic Inspiration die, kullanım ve recovery progression sertifikası.
- Sorcery Points, Metamagic, Pact Magic, Invocation ve Mystic Arcanum progression.
- Wizard Arcane Recovery, Spell Mastery ve Signature Spells doğrulaması.
- College of Valor, Wild Magic, Great Old One ve Abjurer subclass runtime bağlantıları.

# E4 D&D Releases

## 1.8.0

Locations + World Atlas, mekân hiyerarşisi ve NPC bağlantıları.


## Uygulama sürümünü yükseltme

`package.json` ve `package-lock.json` içindeki sürüm numarası birlikte güncellenir.

Örnek:

```powershell
npm.cmd version patch --no-git-tag-version
npm.cmd run check
git add .
git commit -m "release: prepare v1.0.1"
git push
```

## GitHub Release oluşturma

Hazırlık commit'i `main` branch'ine gönderildikten sonra tag oluşturulur:

```powershell
git tag v1.0.1
git push origin v1.0.1
```

`Release` workflow'u otomatik olarak:

1. Bağımlılıkları kurar.
2. Lint, test ve production build çalıştırır.
3. `dist` klasörünü zipler.
4. GitHub Releases bölümünde otomatik sürüm kaydı oluşturur.
5. Production zip dosyasını release'e ekler.

## Uygulama içi sürüm notları

Yeni sürüm için `src/shared/release/releaseNotes.ts` dosyasına en üste yeni kayıt eklenir. Kullanıcı yeni sürümü ilk açtığında notlar bir defa otomatik gösterilir.

## v4.10.0 — Browser E2E & Mobile QA Foundation Mega Pack
- Playwright desktop Chromium and Pixel 7 mobile projects.
- Direct-route smoke coverage for Dashboard, Characters, Builder, Play Mode and Backup.
- Keyboard skip-link, mobile navigation, refresh persistence and offline PWA shell scenarios.
- Shared QA certification manifest for browser, mobile, PWA and data layers.
- Added `test:e2e`, `test:e2e:headed`, `test:e2e:mobile` and `check:full` scripts.
- Browser specs are compile-checked; final execution requires a local Playwright browser that can access the preview server.

## v5.10.0 — Homebrew Creator & Runtime Action Builder

- Visual creator for class, subclass, species, background, feat, spell and item packages.
- Custom resource, recovery and runtime action economy builder.
- Package preview, local storage, JSON import/export and validation.
